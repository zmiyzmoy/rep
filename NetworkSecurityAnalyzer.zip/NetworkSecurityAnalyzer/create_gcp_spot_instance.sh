#!/bin/bash
# Script to create a Google Cloud A100 spot instance for training
# Make it executable: chmod +x create_gcp_spot_instance.sh

# Configuration - Update these values
PROJECT_ID="YOUR_PROJECT_ID"      # Replace with your GCP project ID
ZONE="us-central1-a"              # Zone where you want to create the VM
INSTANCE_NAME="poker-ai-training" # Name for your VM instance
MACHINE_TYPE="a2-highgpu-1g"      # A100 instance with 1 GPU (or choose different type)
BOOT_DISK_SIZE="200GB"            # Boot disk size
SERVICE_ACCOUNT="YOUR_SA"         # Service account email or leave blank for default
GCS_BUCKET="YOUR_BUCKET"          # GCS bucket for storing checkpoints

# Print configuration for confirmation
echo "Creating VM with the following configuration:"
echo "Project: $PROJECT_ID"
echo "Zone: $ZONE"
echo "Instance name: $INSTANCE_NAME"
echo "Machine type: $MACHINE_TYPE"
echo "Boot disk size: $BOOT_DISK_SIZE"
echo "Service account: $SERVICE_ACCOUNT"
echo "GCS bucket: $GCS_BUCKET"
echo ""
read -p "Continue? (y/n) " confirm
if [[ "$confirm" != "y" ]]; then
    echo "Aborted"
    exit 1
fi

# Upload files to GCS for startup script to download
echo "Uploading code files to GCS..."
mkdir -p tmp_code_upload
cp *.py *.sh tmp_code_upload/
gsutil -m cp -r tmp_code_upload/* gs://$GCS_BUCKET/code/
rm -rf tmp_code_upload

# Create the startup script with credentials injected
echo "Preparing startup script..."
cat > tmp_startup.sh <<EOL
#!/bin/bash
# Generated startup script
PROJECT_ID="$PROJECT_ID"
GCS_BUCKET="$GCS_BUCKET"
$(cat gcp_startup.sh | grep -v "PROJECT_ID=" | grep -v "GCS_BUCKET=")
EOL

# Create the VM instance
echo "Creating VM instance..."
gcloud compute instances create $INSTANCE_NAME \
    --project=$PROJECT_ID \
    --zone=$ZONE \
    --machine-type=$MACHINE_TYPE \
    --network-interface=network=default,network-tier=PREMIUM \
    --maintenance-policy=TERMINATE \
    --provisioning-model=SPOT \
    --instance-termination-action=STOP \
    --max-run-duration=604800s \
    --service-account=$SERVICE_ACCOUNT \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --create-disk=auto-delete=yes,boot=yes,device-name=$INSTANCE_NAME,image=projects/ml-images/global/images/c0-deeplearning-common-cu121-v20231203-debian-11-py310,mode=rw,size=$BOOT_DISK_SIZE,type=projects/$PROJECT_ID/zones/$ZONE/diskTypes/pd-balanced \
    --no-shielded-secure-boot \
    --shielded-vtpm \
    --shielded-integrity-monitoring \
    --reservation-affinity=any \
    --metadata-from-file=startup-script=tmp_startup.sh \
    --metadata="install-nvidia-driver=True"

# Clean up temporary files
rm tmp_startup.sh

echo "VM instance creation initiated. Check status with:"
echo "gcloud compute instances describe $INSTANCE_NAME --zone=$ZONE --project=$PROJECT_ID"
echo ""
echo "SSH into the instance with:"
echo "gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --project=$PROJECT_ID"
echo ""
echo "View startup script progress with:"
echo "gcloud compute ssh $INSTANCE_NAME --zone=$ZONE --project=$PROJECT_ID --command='sudo tail -f /var/log/syslog | grep startup-script'"