import os
import time
import logging
import sys
import signal
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.amp import autocast
from torch.cuda.amp import GradScaler
import torch.multiprocessing as mp
import pyspiel
import ray
from tqdm.auto import tqdm
import joblib
from sklearn.cluster import KMeans
from collections import deque
from typing import List, Tuple, Dict, Optional
from open_spiel.python import policy

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('poker_rl.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Import project modules
from models import Config, RegretNet, StrategyNet, StateProcessor, OpponentStats, RewardNormalizer, PrioritizedReplayBuffer, CardEmbedding
from utils import set_random_seed, setup_logging, safe_save_model, load_checkpoint, MultiAgentGameRunner, TournamentEvaluator
from environment import PokerEnvironment, TabularPolicy, TorchPolicy
from psro import PSROSolver, PSROWorker

def parse_args():
    parser = argparse.ArgumentParser(description="Poker Reinforcement Learning System")
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'selfplay'], default='train',
                        help='Operation mode: train, eval or selfplay')
    parser.add_argument('--base_dir', type=str, default='./poker', 
                        help='Base directory for models and logs')
    parser.add_argument('--num_iterations', type=int, default=20, 
                        help='Number of PSRO iterations')
    parser.add_argument('--num_episodes', type=int, default=100, 
                        help='Number of episodes for training or evaluation')
    parser.add_argument('--checkpoint', type=str, default='latest',
                        help='Checkpoint to load (latest, best, or specific path)')
    parser.add_argument('--seed', type=int, default=42, 
                        help='Random seed for reproducibility')
    parser.add_argument('--num_workers', type=int, default=8, 
                        help='Number of parallel workers for training')
    parser.add_argument('--eval_opponents', type=str, default='random,mccfr',
                        help='Comma-separated list of opponents for evaluation')
    parser.add_argument('--verbose', action='store_true', 
                        help='Enable verbose output')
    return parser.parse_args()

def init_config(args):
    """Initialize configuration with command line args."""
    config = Config()
    config.BASE_DIR = args.base_dir
    config.MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_best.pt')
    config.LOG_DIR = os.path.join(config.BASE_DIR, 'logs')
    config.NUM_EPISODES = args.num_episodes
    config.NUM_WORKERS = args.num_workers
    
    # Create directories
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Set log level
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.getLogger().setLevel(log_level)
    
    return config

def train_psro(args, config):
    """Run PSRO training."""
    # Set random seed
    set_random_seed(args.seed)
    
    # Initialize Ray for distributed processing
    if not ray.is_initialized():
        ray.init(ignore_reinit_error=True)
        logging.info("Ray initialized for distributed training")
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize PSRO solver
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint if specified
    if args.checkpoint and args.checkpoint != 'latest':
        solver.load_checkpoints(args.checkpoint)
    
    # Run PSRO iterations
    logging.info(f"Starting PSRO training for {args.num_iterations} iterations...")
    solver.br_policy_iteration(
        num_iterations=args.num_iterations,
        checkpoint_interval=config.CHECKPOINT_INTERVAL
    )
    
    # Final evaluation
    logging.info("Training complete, running final evaluation...")
    evaluate_agent(args, config, solver=solver)
    
    # Shutdown Ray
    ray.shutdown()
    logging.info("PSRO training completed successfully")

def evaluate_agent(args, config, solver=None):
    """Evaluate trained agent against various opponents."""
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Load solver if not provided
    if solver is None:
        solver = PSROSolver(config, state_processor)
        checkpoint_tag = args.checkpoint if args.checkpoint != 'latest' else 'final'
        if not solver.load_checkpoints(checkpoint_tag):
            logging.warning(f"Could not load checkpoint: {checkpoint_tag}")
            # Continue with the initialized solver anyway
            logging.info("Using randomly initialized model for demonstration")
    
    # Parse opponents list
    opponent_types = args.eval_opponents.split(',')
    game = pyspiel.load_game(config.GAME_NAME)
    
    # Create opponent policies
    opponent_policies = []
    for opp_type in opponent_types:
        if opp_type == 'random':
            # Random policy
            opponent_policies.append(policy.UniformRandomPolicy(game))
        elif opp_type == 'mccfr':
            # Try to load MCCFR policy if available in OpenSpiel
            try:
                from open_spiel.python.algorithms import mccfr
                opponent = mccfr.OutcomeSamplingMCCFRSolver(game)
                for _ in tqdm(range(1000), desc="Training MCCFR opponent"):
                    opponent.iteration()
                opponent_policies.append(opponent.average_policy())
            except ImportError:
                logging.warning("MCCFR not available, using random policy instead")
                opponent_policies.append(policy.UniformRandomPolicy(game))
        else:
            logging.warning(f"Unknown opponent type: {opp_type}, using random policy")
            opponent_policies.append(policy.UniformRandomPolicy(game))
    
    # Add our best policy
    our_policy = TorchPolicy(game, solver.regret_net, state_processor)
    
    # Set up evaluator
    evaluator = TournamentEvaluator(config.GAME_NAME, config.NUM_PLAYERS, num_games=args.num_episodes)
    
    # Evaluate against each opponent
    logging.info("Starting evaluation against opponents...")
    
    for i, opp in enumerate(opponent_policies):
        logging.info(f"Evaluating against {opponent_types[i]}...")
        
        # Set up policies for evaluation
        eval_policies = [our_policy, opp]
        
        # Run tournament
        results = evaluator.run_tournament(eval_policies)
        
        # Log results
        logging.info(f"Results against {opponent_types[i]}:")
        logging.info(f"  Our policy vs {opponent_types[i]}: {results[0, 1]:.4f}")
        logging.info(f"  {opponent_types[i]} vs Our policy: {results[1, 0]:.4f}")
    
    logging.info("Evaluation complete")

def selfplay(args, config):
    """Run selfplay mode for demonstration."""
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Load solver
    solver = PSROSolver(config, state_processor)
    checkpoint_tag = args.checkpoint if args.checkpoint != 'latest' else 'final'
    if not solver.load_checkpoints(checkpoint_tag):
        logging.warning(f"Could not load checkpoint: {checkpoint_tag}")
        # Continue with the initialized solver anyway
        logging.info("Using randomly initialized model for demonstration")
    
    # Create policy
    game = pyspiel.load_game(config.GAME_NAME)
    our_policy = TorchPolicy(game, solver.regret_net, state_processor)
    
    # Create environment for selfplay
    env = PokerEnvironment(config.GAME_NAME, config.NUM_PLAYERS)
    
    # Run games
    logging.info("Starting selfplay demonstration...")
    
    for episode in range(args.num_episodes):
        state = env.reset()
        done = False
        episode_actions = []
        
        while not done:
            if state.is_chance_node():
                # Handle chance node
                outcomes = state.chance_outcomes()
                action_list, prob_list = zip(*outcomes)
                action = np.random.choice(action_list, p=prob_list)
            else:
                player = state.current_player()
                # All players use our policy
                action_probs = our_policy.action_probabilities(state)
                actions, probs = zip(*action_probs.items())
                
                # Ensure probabilities sum to 1
                probs = np.array(probs)
                probs_sum = probs.sum()
                if abs(probs_sum - 1.0) > 1e-6:
                    probs = probs / probs_sum
                
                action = np.random.choice(actions, p=probs)
                
                # Log decision
                info_state = state.information_state_string(player)
                episode_actions.append((player, action))
            
            # Apply action
            state, rewards, done, info = env.step(action)
        
        # Log episode results
        logging.info(f"Episode {episode+1} complete")
        logging.info(f"  Final returns: {rewards}")
        if args.verbose:
            logging.info(f"  Actions: {episode_actions}")
    
    logging.info("Selfplay demonstration complete")

def main():
    args = parse_args()
    config = init_config(args)
    
    # Register signal handlers for graceful shutdown
    def signal_handler(sig, frame):
        logging.info("Received termination signal, shutting down gracefully...")
        if ray.is_initialized():
            ray.shutdown()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run in selected mode
    if args.mode == 'train':
        train_psro(args, config)
    elif args.mode == 'eval':
        evaluate_agent(args, config)
    elif args.mode == 'selfplay':
        selfplay(args, config)
    else:
        logging.error(f"Unknown mode: {args.mode}")

if __name__ == "__main__":
    main()
