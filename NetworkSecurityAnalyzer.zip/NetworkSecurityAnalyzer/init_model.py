import os
import logging
import torch
import torch.optim as optim
from models import Config, RegretNet, StrategyNet, StateProcessor
from environment import TabularPolicy
import pyspiel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('init_model.log'),
        logging.StreamHandler()
    ]
)

def main():
    """Initialize and save a basic model for the PSRO algorithm."""
    # Initialize configuration
    config = Config()
    
    # Create directories
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")
    
    # Load game
    game = pyspiel.load_game(config.GAME_NAME)
    num_actions = game.num_distinct_actions()
    logging.info(f"Game loaded with {num_actions} distinct actions")
    
    # Initialize models
    regret_net = RegretNet(state_processor.state_size, num_actions).to(device)
    strategy_net = StrategyNet(state_processor.state_size, num_actions).to(device)
    
    # Initialize optimizers
    regret_optimizer = optim.Adam(regret_net.parameters(), lr=config.LEARNING_RATE)
    strategy_optimizer = optim.Adam(strategy_net.parameters(), lr=config.LEARNING_RATE)
    
    # Save models
    checkpoint = {
        'epoch': 0,
        'regret_net_state_dict': regret_net.state_dict(),
        'strategy_net_state_dict': strategy_net.state_dict(),
        'regret_optimizer_state_dict': regret_optimizer.state_dict(),
        'strategy_optimizer_state_dict': strategy_optimizer.state_dict(),
        'strategy_pool': [TabularPolicy(game).serialize()],
        'meta_strategies': [1.0]
    }
    
    # Save to different checkpoint files
    torch.save(checkpoint, config.MODEL_PATH)
    torch.save(checkpoint, config.MODEL_PATH + ".final")
    torch.save(checkpoint, config.MODEL_PATH + ".best")
    
    logging.info(f"Initial model saved to {config.MODEL_PATH}")
    logging.info(f"Initial model saved to {config.MODEL_PATH}.final")
    logging.info(f"Initial model saved to {config.MODEL_PATH}.best")
    
    return True

if __name__ == "__main__":
    main()