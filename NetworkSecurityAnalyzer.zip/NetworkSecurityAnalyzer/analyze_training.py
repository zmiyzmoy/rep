#!/usr/bin/env python3
import os
import json
import argparse
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

def parse_args():
    parser = argparse.ArgumentParser(description="Analyze Poker AI Training")
    parser.add_argument('--metrics_file', type=str, default='./poker/logs/metrics.json',
                        help='Path to metrics JSON file')
    parser.add_argument('--output_dir', type=str, default='./poker/analysis',
                        help='Directory to save analysis results')
    parser.add_argument('--checkpoint_dir', type=str, default='./poker/checkpoints',
                        help='Directory with checkpoints')
    return parser.parse_args()

def load_metrics(metrics_file):
    """Load metrics from JSON file."""
    if not os.path.exists(metrics_file):
        print(f"Metrics file not found: {metrics_file}")
        return None
    
    try:
        with open(metrics_file, 'r') as f:
            metrics = json.load(f)
        return metrics
    except Exception as e:
        print(f"Error loading metrics: {e}")
        return None

def analyze_checkpoints(checkpoint_dir):
    """Analyze checkpoint files and their timestamps."""
    if not os.path.exists(checkpoint_dir):
        print(f"Checkpoint directory not found: {checkpoint_dir}")
        return None
    
    checkpoint_data = []
    
    # Get list of checkpoint files
    checkpoint_files = [f for f in os.listdir(checkpoint_dir) 
                      if f.endswith('.pt.final') or f.endswith('.pt.best')]
    
    for cf in checkpoint_files:
        path = os.path.join(checkpoint_dir, cf)
        stats = os.stat(path)
        
        # Extract checkpoint type and iteration if possible
        cp_type = "unknown"
        iteration = None
        
        if cf.endswith(".pt.final"):
            cp_type = "final"
            parts = cf.split("_")
            if len(parts) > 1 and parts[0] == "iteration":
                try:
                    iteration = int(parts[1])
                except:
                    pass
        elif cf.endswith(".pt.best"):
            cp_type = "best"
        
        checkpoint_data.append({
            "file": cf,
            "type": cp_type,
            "iteration": iteration,
            "size_mb": stats.st_size / (1024 * 1024),
            "modified": datetime.fromtimestamp(stats.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
            "timestamp": stats.st_mtime
        })
    
    # Sort by modified time
    checkpoint_data.sort(key=lambda x: x["timestamp"])
    
    return checkpoint_data

def plot_metrics(metrics, output_dir):
    """Plot training metrics."""
    if not metrics:
        return
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Plot win rates if available
    if 'win_rates' in metrics and metrics['win_rates']:
        plt.figure(figsize=(10, 6))
        iterations = range(len(metrics['win_rates']))
        plt.plot(iterations, metrics['win_rates'], marker='o', linestyle='-')
        plt.title('Win Rate vs Random Agent')
        plt.xlabel('Evaluation Interval')
        plt.ylabel('Win Rate')
        plt.grid(True)
        plt.savefig(os.path.join(output_dir, 'win_rates_curve.png'))
        plt.close()
    
    # Plot exploitability if available
    if 'exploitability' in metrics and metrics['exploitability']:
        plt.figure(figsize=(10, 6))
        iterations = range(len(metrics['exploitability']))
        plt.plot(iterations, metrics['exploitability'], marker='o', linestyle='-')
        plt.title('Exploitability')
        plt.xlabel('Evaluation Interval')
        plt.ylabel('Exploitability')
        plt.yscale('log')  # Often better to view on log scale
        plt.grid(True)
        plt.savefig(os.path.join(output_dir, 'exploitability_curve.png'))
        plt.close()
    
    # Plot training time per iteration
    if 'training_time' in metrics and metrics['training_time']:
        plt.figure(figsize=(10, 6))
        iterations = range(len(metrics['training_time']))
        plt.plot(iterations, metrics['training_time'], marker='o', linestyle='-')
        plt.title('Training Time per Iteration')
        plt.xlabel('Iteration')
        plt.ylabel('Time (seconds)')
        plt.grid(True)
        plt.savefig(os.path.join(output_dir, 'training_time_curve.png'))
        plt.close()
    
    # Plot policy size growth
    if 'policy_size' in metrics and metrics['policy_size']:
        plt.figure(figsize=(10, 6))
        iterations = range(len(metrics['policy_size']))
        plt.plot(iterations, metrics['policy_size'], marker='o', linestyle='-')
        plt.title('Strategy Pool Size')
        plt.xlabel('Iteration')
        plt.ylabel('Number of Strategies')
        plt.grid(True)
        plt.savefig(os.path.join(output_dir, 'policy_size_curve.png'))
        plt.close()
    
    # Plot losses if available
    if 'losses' in metrics and metrics['losses']:
        plt.figure(figsize=(10, 6))
        iterations = range(len(metrics['losses']))
        plt.plot(iterations, metrics['losses'], marker='o', linestyle='-')
        plt.title('Training Losses')
        plt.xlabel('Iteration')
        plt.ylabel('Loss')
        plt.grid(True)
        plt.savefig(os.path.join(output_dir, 'losses_curve.png'))
        plt.close()
    
    return

def generate_report(metrics, checkpoint_data, output_dir):
    """Generate a comprehensive HTML report."""
    if not metrics and not checkpoint_data:
        return
    
    os.makedirs(output_dir, exist_ok=True)
    
    report_path = os.path.join(output_dir, 'training_report.html')
    
    with open(report_path, 'w') as f:
        f.write("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Poker AI Training Report</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .container { max-width: 1200px; margin: 0 auto; }
                .metrics { margin-bottom: 30px; }
                .checkpoints { margin-bottom: 30px; }
                table { border-collapse: collapse; width: 100%; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                tr:nth-child(even) { background-color: #f9f9f9; }
                h1, h2 { color: #333; }
                .charts { display: flex; flex-wrap: wrap; justify-content: space-around; }
                .chart { margin: 10px; max-width: 45%; }
                .chart img { max-width: 100%; height: auto; }
                .summary { background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Poker AI Training Report</h1>
                <div class="summary">
                    <h2>Summary</h2>
        """)
        
        # Add summary information
        if metrics:
            num_iterations = len(metrics.get('training_time', []))
            total_time = sum(metrics.get('training_time', [0]))
            best_win_rate = max(metrics.get('win_rates', [0]))
            best_exploitability = min(metrics.get('exploitability', [float('inf')]))
            if best_exploitability == float('inf'):
                best_exploitability = "N/A"
            
            f.write(f"""
                    <p><strong>Total Iterations:</strong> {num_iterations}</p>
                    <p><strong>Total Training Time:</strong> {total_time/3600:.2f} hours</p>
                    <p><strong>Best Win Rate vs Random:</strong> {best_win_rate:.4f}</p>
                    <p><strong>Best Exploitability:</strong> {best_exploitability}</p>
            """)
        
        if checkpoint_data:
            last_checkpoint = checkpoint_data[-1]
            f.write(f"""
                    <p><strong>Last Checkpoint:</strong> {last_checkpoint['file']}</p>
                    <p><strong>Last Checkpoint Time:</strong> {last_checkpoint['modified']}</p>
                    <p><strong>Total Checkpoints:</strong> {len(checkpoint_data)}</p>
            """)
        
        f.write("""
                </div>
                
                <div class="animations">
                    <h2>Learning Progress Animations</h2>
                    <div style="display: flex; justify-content: space-around; flex-wrap: wrap;">
                        <div style="text-align: center; margin: 15px; max-width: 45%;">
                            <h3>Win Rate Progression</h3>
                            <img src="win_rates_animated.gif" alt="Win Rate Animation" style="max-width: 100%;">
                        </div>
                        <div style="text-align: center; margin: 15px; max-width: 45%;">
                            <h3>Exploitability Reduction</h3>
                            <img src="exploitability_animated.gif" alt="Exploitability Animation" style="max-width: 100%;">
                        </div>
                    </div>
                </div>
                
                <div class="charts">
                    <h2>Static Analysis Charts</h2>
                    <div class="chart">
                        <h3>Win Rates</h3>
                        <img src="win_rates_curve.png" alt="Win Rates Chart">
                    </div>
                    <div class="chart">
                        <h3>Exploitability</h3>
                        <img src="exploitability_curve.png" alt="Exploitability Chart">
                    </div>
                    <div class="chart">
                        <h3>Training Time</h3>
                        <img src="training_time_curve.png" alt="Training Time Chart">
                    </div>
                    <div class="chart">
                        <h3>Strategy Pool Size</h3>
                        <img src="policy_size_curve.png" alt="Policy Size Chart">
                    </div>
                </div>
                
                <div class="learning-summary" style="background-color: #f5f8ff; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h2>Learning Summary</h2>
                    <div id="learning-summary-content">
                        <p>See the detailed learning summary file: <a href="learning_summary.md">learning_summary.md</a></p>
                    </div>
                </div>
                
                <div class="checkpoints">
                    <h2>Checkpoints</h2>
                    <table>
                        <tr>
                            <th>File</th>
                            <th>Type</th>
                            <th>Iteration</th>
                            <th>Size (MB)</th>
                            <th>Modified</th>
                        </tr>
        """)
        
        # Add checkpoint data
        if checkpoint_data:
            for cp in checkpoint_data:
                iteration = cp['iteration'] if cp['iteration'] is not None else "N/A"
                f.write(f"""
                        <tr>
                            <td>{cp['file']}</td>
                            <td>{cp['type']}</td>
                            <td>{iteration}</td>
                            <td>{cp['size_mb']:.2f}</td>
                            <td>{cp['modified']}</td>
                        </tr>
                """)
        
        f.write("""
                    </table>
                </div>
                
                <div class="metrics">
                    <h2>Detailed Metrics</h2>
                    <pre id="metrics-json"></pre>
                    <script>
                        document.getElementById('metrics-json').textContent = 
                            JSON.stringify(""")
        
        if metrics:
            f.write(json.dumps(metrics, indent=2))
        else:
            f.write("{}")
        
        f.write(""", null, 2);
                    </script>
                </div>
                
                <div>
                    <p><em>Report generated on """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</em></p>
                </div>
            </div>
        </body>
        </html>
        """)
    
    print(f"Report generated: {report_path}")
    return report_path

def main():
    args = parse_args()
    
    # Load metrics
    metrics = load_metrics(args.metrics_file)
    
    # Analyze checkpoints
    checkpoint_data = analyze_checkpoints(args.checkpoint_dir)
    
    # Plot metrics
    if metrics:
        plot_metrics(metrics, args.output_dir)
    
    # Generate report
    report_path = generate_report(metrics, checkpoint_data, args.output_dir)
    
    if report_path:
        print(f"Analysis complete. Report available at: {report_path}")
    else:
        print("Analysis failed. No report generated.")

if __name__ == "__main__":
    main()