import os
import time
import logging
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import ray
import gc
from torch.amp import autocast
from torch.cuda.amp import GradScaler
from typing import List, Dict, Tuple, Any, Optional
import pyspiel
from open_spiel.python import policy as openspiel_policy
from open_spiel.python.algorithms import exploitability
from torch.utils.tensorboard import SummaryWriter

# Import local modules
from models import RegretNet, StrategyNet, CardEmbedding, StateProcessor, OpponentStats, RewardNormalizer
from environment import PokerEnvironment, TabularPolicy, TorchPolicy

class PSROSolver:
    """Policy Space Response Oracles (PSRO) algorithm."""
    
    def __init__(self, config, state_processor):
        self.config = config
        self.state_processor = state_processor
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.game = pyspiel.load_game(config.GAME_NAME)
        self.num_actions = self.game.num_distinct_actions()
        self.meta_game_matrix = None
        
        # Initialize models
        self.regret_net = RegretNet(state_processor.state_size, self.num_actions).to(self.device)
        self.strategy_net = StrategyNet(state_processor.state_size, self.num_actions).to(self.device)
        
        # Initialize optimizers
        self.regret_optimizer = optim.Adam(self.regret_net.parameters(), lr=config.LEARNING_RATE)
        self.strategy_optimizer = optim.Adam(self.strategy_net.parameters(), lr=config.LEARNING_RATE)
        
        # Mixed precision training
        self.scaler = GradScaler('cuda') if torch.cuda.is_available() else GradScaler()
        
        # Strategy pool
        self.strategy_pool = []
        self.meta_strategies = []
        
        # TensorBoard logging
        self.writer = SummaryWriter(log_dir=os.path.join(config.LOG_DIR, 'tensorboard'))
        self.global_step = 0
        
        # Reward normalization
        self.reward_normalizer = RewardNormalizer()
        
        # Metrics tracking
        self.metrics = {
            'win_rates': [],
            'exploitability': [],
            'training_time': [],
            'policy_size': [],
            'losses': []
        }
        
        # Initialize the first random/uniform strategy
        initial_policy = TabularPolicy(self.game)
        self.strategy_pool.append(initial_policy)
        self.meta_strategies = [1.0]  # 100% weight on initial policy
        
        logging.info(f"PSROSolver initialized with {self.num_actions} actions")
        
        logging.info(f"PSROSolver initialized with {self.num_actions} actions")
    
    def compute_meta_strategies(self):
        """Compute meta strategies for the current strategy pool."""
        # Meta-strategy computation with Nash equilibrium or uniform strategy
        if len(self.strategy_pool) == 1:
            return [1.0]
        
        # Compute meta-game payoff matrix
        self._update_meta_game_matrix()
        
        # For simplicity in this implementation, use uniform meta-strategy
        # In a full implementation, compute Nash equilibrium
        return [1.0 / len(self.strategy_pool)] * len(self.strategy_pool)
    
    def _update_meta_game_matrix(self):
        """Update the empirical meta-game payoff matrix."""
        n = len(self.strategy_pool)
        if self.meta_game_matrix is None or self.meta_game_matrix.shape != (n, n):
            # Initialize or resize meta-game matrix
            old_matrix = self.meta_game_matrix
            self.meta_game_matrix = np.zeros((n, n))
            
            # Copy existing values if matrix is being resized
            if old_matrix is not None:
                old_n = old_matrix.shape[0]
                self.meta_game_matrix[:old_n, :old_n] = old_matrix
        
        # Compute missing entries
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        
        for i in range(n):
            for j in range(n):
                # Skip already computed entries
                if i < n-1 and j < n-1:
                    continue
                
                # Compute average payoff when i plays against j
                payoffs = []
                for _ in range(10):  # Small number for efficiency
                    state = env.reset()
                    done = False
                    
                    while not done:
                        if state.is_chance_node():
                            # Handle chance node
                            outcomes = state.chance_outcomes()
                            action_list, prob_list = zip(*outcomes)
                            action = np.random.choice(action_list, p=prob_list)
                        else:
                            player = state.current_player()
                            # Alternate between policies based on player index
                            policy_idx = i if player % 2 == 0 else j
                            policy = self.strategy_pool[policy_idx]
                            
                            # Get action from policy
                            action_probs = policy.action_probabilities(state)
                            actions, probs = zip(*action_probs.items())
                            action = np.random.choice(actions, p=probs)
                        
                        # Apply action
                        state.apply_action(action)
                        done = state.is_terminal()
                    
                    # Get payoffs
                    returns = state.returns()
                    payoffs.append(returns[0])  # First player's perspective
                
                # Update meta-game matrix
                self.meta_game_matrix[i, j] = np.mean(payoffs)
    
    def add_strategy_to_pool(self, new_policy):
        """Add a new strategy to the pool."""
        if len(self.strategy_pool) >= self.config.MAX_STRATEGY_POOL:
            # Remove a strategy with lowest meta-strategy weight
            if self.meta_strategies:
                idx_to_remove = np.argmin(self.meta_strategies)
                self.strategy_pool.pop(idx_to_remove)
                self.meta_strategies = self.meta_strategies[:idx_to_remove] + self.meta_strategies[idx_to_remove+1:]
            else:
                # If no meta-strategies, remove oldest
                self.strategy_pool.pop(0)
        
        # Add new strategy
        self.strategy_pool.append(new_policy)
        
        # Recompute meta-strategies
        self.meta_strategies = self.compute_meta_strategies()
        logging.info(f"Added new strategy to pool. Pool size: {len(self.strategy_pool)}")
    
    def sample_strategy_from_pool(self):
        """Sample a strategy from the pool according to meta-strategies."""
        if not self.strategy_pool:
            return None
        
        if not self.meta_strategies or len(self.meta_strategies) != len(self.strategy_pool):
            self.meta_strategies = [1.0 / len(self.strategy_pool)] * len(self.strategy_pool)
        
        idx = np.random.choice(len(self.strategy_pool), p=self.meta_strategies)
        return self.strategy_pool[idx]
    
    def br_policy_iteration(self, num_iterations=100, checkpoint_interval=None):
        """Best response policy iteration (PSRO main loop)."""
        start_time = time.time()
        last_checkpoint_time = start_time
        
        logging.info(f"Starting PSRO training for {num_iterations} iterations")
        self.writer.add_text('PSRO/Config', str(self.config.__dict__), 0)
        
        for iteration in range(num_iterations):
            iteration_start = time.time()
            logging.info(f"Starting PSRO iteration {iteration+1}/{num_iterations}")
            
            # 1. Sample strategy profile from meta-strategies
            opponent_strategy = self.sample_strategy_from_pool()
            
            # 2. Train best response against sampled strategy
            self.train_best_response(opponent_strategy, num_episodes=self.config.NUM_EPISODES)
            
            # 3. Extract policy from trained best response
            br_policy = self.extract_policy_from_model()
            
            # 4. Add best response to strategy pool
            self.add_strategy_to_pool(br_policy)
            
            # 5. Recompute meta-strategies
            self.meta_strategies = self.compute_meta_strategies()
            
            # 6. Evaluate exploitability if game is small enough
            if self.config.NUM_PLAYERS <= 2 and self.game.num_distinct_actions() < 100:
                try:
                    expl = exploitability.exploitability(self.game, br_policy)
                    self.metrics['exploitability'].append(float(expl))
                    self.writer.add_scalar('Metrics/exploitability', expl, iteration)
                    logging.info(f"Exploitability: {expl:.6f}")
                except Exception as e:
                    logging.error(f"Error computing exploitability: {e}")
            
            # 7. Track win rate against random agent
            try:
                win_rate = self._evaluate_against_random(100)
                self.metrics['win_rates'].append(float(win_rate))
                self.writer.add_scalar('Metrics/win_rate_vs_random', win_rate, iteration)
                logging.info(f"Win rate vs random: {win_rate:.2f}")
            except Exception as e:
                logging.error(f"Error evaluating win rate: {e}")
            
            # 8. Track meta-strategy distribution
            self.writer.add_histogram('PSRO/meta_strategy', 
                                    torch.tensor(self.meta_strategies), 
                                    iteration)
            
            # 9. Track policy size
            self.metrics['policy_size'].append(len(self.strategy_pool))
            self.writer.add_scalar('PSRO/strategy_pool_size', len(self.strategy_pool), iteration)
            
            # 10. Track iteration time
            iteration_time = time.time() - iteration_start
            self.metrics['training_time'].append(float(iteration_time))
            self.writer.add_scalar('PSRO/iteration_time', iteration_time, iteration)
            
            # Log progress
            logging.info(f"Completed PSRO iteration {iteration+1}: Strategy pool size={len(self.strategy_pool)}, Time={iteration_time:.2f}s")
            
            # Checkpoint if needed
            current_time = time.time()
            if checkpoint_interval and (current_time - last_checkpoint_time) >= checkpoint_interval:
                self.save_checkpoints(f"iteration_{iteration+1}")
                # Also save best checkpoint if this has the best win rate
                if self.metrics['win_rates'] and win_rate == max(self.metrics['win_rates']):
                    self.save_checkpoints("best")
                    logging.info(f"Saved best checkpoint with win rate: {win_rate:.2f}")
                    
                last_checkpoint_time = current_time
                
                # Save metrics to disk
                metrics_path = os.path.join(self.config.LOG_DIR, 'metrics.json')
                try:
                    import json
                    with open(metrics_path, 'w') as f:
                        json.dump(self.metrics, f)
                    logging.info(f"Metrics saved to {metrics_path}")
                except Exception as e:
                    logging.error(f"Failed to save metrics: {e}")
                
        # Final checkpoint
        self.save_checkpoints("final")
        
        # Final cleanup
        self.writer.close()
        
        total_time = time.time() - start_time
        logging.info(f"PSRO completed in {total_time:.2f} seconds")
        self.writer.add_text('PSRO/Summary', 
                           f"Training completed in {total_time:.2f}s with {len(self.strategy_pool)} strategies", 
                           num_iterations)
        
        return self.strategy_pool, self.meta_strategies
        
    def _evaluate_against_random(self, num_games=100):
        """Evaluate current policy against a random agent."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        policy = self.extract_policy_from_model()
        random_policy = TabularPolicy(self.game)  # Default is uniform random
        
        wins = 0
        for _ in range(num_games):
            state = env.reset()
            done = False
            
            while not done:
                if state.is_chance_node():
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    action = np.random.choice(action_list, p=prob_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                
                # Player 0 uses our policy, others use random
                if player == 0:
                    action_probs = policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    action = np.random.choice(actions, p=probs)
                else:
                    action_probs = random_policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    action = np.random.choice(actions, p=probs)
                
                # Apply action
                state.apply_action(action)
                done = state.is_terminal()
            
            # Get final rewards
            returns = state.returns()
            if returns[0] > 0:
                wins += 1
        
        return wins / num_games
    
    def train_best_response(self, opponent_strategy, num_episodes=10):
        """Train best response against a given opponent strategy."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        self.regret_net.train()
        
        # Initialize experience buffer
        buffer = []
        
        # Collect experience
        for episode in range(num_episodes):
            state = env.reset()
            done = False
            trajectory = []
            
            while not done:
                if state.is_chance_node():
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    action = np.random.choice(action_list, p=prob_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                legal_actions = state.legal_actions()
                
                # Process state
                processed_state = self.state_processor.process([state], [player])
                state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
                
                # Use opponent strategy for all players except current training player
                if player != 0:  # Assuming we're training player 0
                    if opponent_strategy:
                        action_probs = opponent_strategy.action_probabilities(state)
                        actions, probs = zip(*action_probs.items())
                        action = np.random.choice(actions, p=probs)
                    else:
                        # Random action if no opponent strategy
                        action = random.choice(legal_actions)
                else:
                    # Use epsilon-greedy for exploration
                    epsilon = max(0.1, 1.0 - episode / num_episodes)
                    
                    if random.random() < epsilon:
                        action = random.choice(legal_actions)
                    else:
                        with torch.no_grad():
                            regret_values = self.regret_net(state_tensor)[0].cpu().numpy()
                            # Mask illegal actions
                            mask = np.ones_like(regret_values) * float('-inf')
                            mask[legal_actions] = 0
                            masked_values = regret_values + mask
                            action = np.argmax(masked_values)
                
                # Store transition
                info_state = state.information_state_string(player)
                reward = 0  # Placeholder, will be updated later
                
                trajectory.append({
                    'info_state': info_state,
                    'state': state.clone(),
                    'action': action,
                    'legal_actions': legal_actions,
                    'player': player,
                    'reward': reward,
                    'next_state': None,
                    'done': False
                })
                
                # Apply action
                state.apply_action(action)
                done = state.is_terminal()
            
            # Get final rewards
            returns = state.returns()
            
            # Update rewards in trajectory
            for transition in trajectory:
                transition['reward'] = returns[transition['player']]
                transition['done'] = True
            
            buffer.extend(trajectory)
            
            if (episode + 1) % 10 == 0:
                logging.info(f"Episode {episode+1}/{num_episodes} completed, buffer size: {len(buffer)}")
        
        # Train on collected experience
        self._train_on_buffer(buffer)
        
        # Reset model to eval mode
        self.regret_net.eval()
        logging.info("Best response training completed")
    
    def _train_on_buffer(self, buffer, batch_size=64, epochs=5):
        """Train models on collected experience."""
        if not buffer:
            logging.warning("Empty buffer, skipping training")
            return
        
        # Prepare data
        states = [item['state'] for item in buffer]
        players = [item['player'] for item in buffer]
        actions = torch.tensor([item['action'] for item in buffer], dtype=torch.long, device=self.device)
        
        # Normalize rewards
        raw_rewards = [item['reward'] for item in buffer]
        for reward in raw_rewards:
            self.reward_normalizer.update(reward)
            
        normalized_rewards = [self.reward_normalizer.normalize(r) for r in raw_rewards]
        rewards = torch.tensor(normalized_rewards, dtype=torch.float32, device=self.device)
        
        # Log reward statistics
        self.writer.add_histogram('Rewards/raw', torch.tensor(raw_rewards), self.global_step)
        self.writer.add_histogram('Rewards/normalized', rewards, self.global_step)
        self.writer.add_scalar('Rewards/mean', self.reward_normalizer.mean, self.global_step)
        self.writer.add_scalar('Rewards/std', self.reward_normalizer.std, self.global_step)
        
        # Process states
        processed_states = self.state_processor.process(states, players)
        states_tensor = torch.tensor(processed_states, dtype=torch.float32, device=self.device)
        
        dataset_size = len(buffer)
        indices = list(range(dataset_size))
        
        epoch_losses = []
        for epoch in range(epochs):
            random.shuffle(indices)
            total_loss = 0
            batch_count = 0
            
            for start_idx in range(0, dataset_size, batch_size):
                batch_indices = indices[start_idx:min(start_idx + batch_size, dataset_size)]
                batch_count += 1
                
                # Get batch data
                batch_states = states_tensor[batch_indices]
                batch_actions = actions[batch_indices]
                batch_rewards = rewards[batch_indices]
                
                # Zero gradients
                self.regret_optimizer.zero_grad()
                
                # Forward pass without mixed precision to avoid BFloat16 issues
                batch_states = batch_states.to(dtype=torch.float32)
                regret_values = self.regret_net(batch_states)
                
                # Get regret values for taken actions
                selected_regrets = regret_values.gather(1, batch_actions.unsqueeze(1)).squeeze(1)
                
                # MSE loss between regret prediction and actual reward
                loss = nn.MSELoss()(selected_regrets, batch_rewards)
                
                # Backward and optimize with gradient scaling
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.regret_optimizer)
                torch.nn.utils.clip_grad_norm_(self.regret_net.parameters(), self.config.GRAD_CLIP_VALUE)
                self.scaler.step(self.regret_optimizer)
                self.scaler.update()
                
                # Log batch loss
                batch_loss = loss.item()
                total_loss += batch_loss
                self.writer.add_scalar('Training/batch_loss', batch_loss, self.global_step)
                self.global_step += 1
            
            # Calculate and log epoch loss
            avg_loss = total_loss / batch_count if batch_count > 0 else 0
            epoch_losses.append(avg_loss)
            self.writer.add_scalar('Training/epoch_loss', avg_loss, epoch)
            
            logging.info(f"Epoch {epoch+1}/{epochs}, Average loss: {avg_loss:.6f}")
        
        # Store metrics
        self.metrics['losses'].append(np.mean(epoch_losses))
        
        # Periodically save metrics to disk
        if self.global_step % 500 == 0:
            metrics_path = os.path.join(self.config.LOG_DIR, 'metrics.json')
            try:
                import json
                with open(metrics_path, 'w') as f:
                    json.dump(self.metrics, f)
                logging.info(f"Metrics saved to {metrics_path}")
            except Exception as e:
                logging.error(f"Failed to save metrics: {e}")
                
        # Run garbage collection to prevent memory leaks
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def extract_policy_from_model(self):
        """Extract a policy from the trained regret network."""
        self.regret_net.eval()
        
        # Create a tabular policy for storage efficiency
        br_policy = TabularPolicy(self.game)
        
        # Sample states for policy extraction
        sampled_states = self._sample_info_states()
        
        for info_state, state in sampled_states.items():
            legal_actions = state.legal_actions()
            if not legal_actions:
                continue
            
            player = state.current_player()
            processed_state = self.state_processor.process([state], [player])
            state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
            
            with torch.no_grad():
                regret_values = self.regret_net(state_tensor)[0].cpu().numpy()
            
            # Convert regret values to policy
            # Use softmax with temperature for better exploration
            temperature = 0.5
            masked_values = np.ones_like(regret_values) * float('-inf')
            masked_values[legal_actions] = regret_values[legal_actions]
            
            # Apply softmax
            policy_probs = np.exp(masked_values / temperature)
            policy_probs = policy_probs / np.sum(policy_probs)
            
            # Add to policy table
            br_policy.update(info_state, {a: policy_probs[a] for a in legal_actions})
        
        return br_policy
    
    def _sample_info_states(self, num_games=50, max_states=1000):
        """Sample information states from random games."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        sampled_states = {}
        
        for _ in range(num_games):
            if len(sampled_states) >= max_states:
                break
                
            state = env.reset()
            done = False
            
            while not done and len(sampled_states) < max_states:
                if state.is_chance_node():
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    action = np.random.choice(action_list, p=prob_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                info_state = state.information_state_string(player)
                
                # Store state if not already sampled
                if info_state not in sampled_states:
                    sampled_states[info_state] = state.clone()
                
                # Random action
                action = random.choice(state.legal_actions())
                state.apply_action(action)
                done = state.is_terminal()
        
        logging.info(f"Sampled {len(sampled_states)} unique information states")
        return sampled_states
    
    def save_checkpoints(self, tag="checkpoint"):
        """Save model checkpoints."""
        os.makedirs(os.path.dirname(self.config.MODEL_PATH), exist_ok=True)
        
        # Save neural networks
        torch.save({
            'regret_net': self.regret_net.state_dict(),
            'strategy_net': self.strategy_net.state_dict(),
            'regret_optimizer': self.regret_optimizer.state_dict(),
            'strategy_optimizer': self.strategy_optimizer.state_dict(),
        }, f"{self.config.MODEL_PATH}.{tag}")
        
        # Save strategy pool
        strategies = []
        for i, strategy in enumerate(self.strategy_pool):
            if hasattr(strategy, 'serialize'):
                strategies.append(strategy.serialize())
            else:
                logging.warning(f"Strategy {i} cannot be serialized, skipping")
        
        # Save meta-strategies
        np.savez(
            f"{self.config.MODEL_PATH}.{tag}.meta",
            meta_strategies=np.array(self.meta_strategies),
            meta_game_matrix=self.meta_game_matrix if self.meta_game_matrix is not None else np.array([]),
            strategies=strategies
        )
        
        logging.info(f"Saved checkpoints with tag: {tag}")
    
    def load_checkpoints(self, tag="checkpoint"):
        """Load model checkpoints."""
        checkpoint_path = f"{self.config.MODEL_PATH}.{tag}"
        meta_path = f"{self.config.MODEL_PATH}.{tag}.meta"
        
        if not os.path.exists(checkpoint_path):
            logging.warning(f"Checkpoint not found: {checkpoint_path}")
            return False
        
        # Load neural networks
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        # The init_model.py saves with different keys than expected here
        if 'regret_net_state_dict' in checkpoint:
            self.regret_net.load_state_dict(checkpoint['regret_net_state_dict'])
            self.strategy_net.load_state_dict(checkpoint['strategy_net_state_dict'])
            if 'regret_optimizer_state_dict' in checkpoint:
                self.regret_optimizer.load_state_dict(checkpoint['regret_optimizer_state_dict'])
            if 'strategy_optimizer_state_dict' in checkpoint:
                self.strategy_optimizer.load_state_dict(checkpoint['strategy_optimizer_state_dict'])
        elif 'regret_net' in checkpoint:
            self.regret_net.load_state_dict(checkpoint['regret_net'])
            self.strategy_net.load_state_dict(checkpoint['strategy_net'])
            # Only try to load optimizer states if they exist
            if 'regret_optimizer' in checkpoint:
                self.regret_optimizer.load_state_dict(checkpoint['regret_optimizer'])
            if 'strategy_optimizer' in checkpoint:
                self.strategy_optimizer.load_state_dict(checkpoint['strategy_optimizer'])
        
        # Load meta-strategies if available
        if os.path.exists(meta_path):
            meta_data = np.load(meta_path, allow_pickle=True)
            
            if 'meta_strategies' in meta_data:
                self.meta_strategies = meta_data['meta_strategies'].tolist()
            
            if 'meta_game_matrix' in meta_data and meta_data['meta_game_matrix'].size > 0:
                self.meta_game_matrix = meta_data['meta_game_matrix']
            
            # Load strategy pool if available
            if 'strategies' in meta_data:
                self.strategy_pool = []
                for strategy_data in meta_data['strategies']:
                    try:
                        policy = TabularPolicy.deserialize(self.game, strategy_data)
                        self.strategy_pool.append(policy)
                    except Exception as e:
                        logging.error(f"Error loading strategy: {e}")
        
        logging.info(f"Loaded checkpoints with tag: {tag}")
        return True

@ray.remote
class PSROWorker:
    """Distributed worker for PSRO training."""
    
    def __init__(self, config, worker_id):
        self.config = config
        self.worker_id = worker_id
        self.game = pyspiel.load_game(config.GAME_NAME)
        self.state_processor = StateProcessor(config)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize models
        self.regret_net = RegretNet(self.state_processor.state_size, self.game.num_distinct_actions()).to(self.device)
        self.strategy_net = StrategyNet(self.state_processor.state_size, self.game.num_distinct_actions()).to(self.device)
        
        logging.info(f"PSROWorker {worker_id} initialized")
    
    def update_models(self, regret_state_dict, strategy_state_dict):
        """Update model weights from main solver."""
        self.regret_net.load_state_dict(regret_state_dict)
        self.strategy_net.load_state_dict(strategy_state_dict)
        return True
    
    def collect_experience(self, opponent_policies, steps):
        """Collect experience by playing against opponent policies."""
        env = PokerEnvironment(self.config.GAME_NAME, self.config.NUM_PLAYERS)
        buffer = []
        
        for _ in range(steps):
            state = env.reset()
            done = False
            trajectory = []
            
            while not done:
                if state.is_chance_node():
                    # Handle chance node
                    outcomes = state.chance_outcomes()
                    action_list, prob_list = zip(*outcomes)
                    action = np.random.choice(action_list, p=prob_list)
                    state.apply_action(action)
                    continue
                
                player = state.current_player()
                legal_actions = state.legal_actions()
                
                # Process state
                processed_state = self.state_processor.process([state], [player])
                state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
                
                # Select action:
                # Player 0 uses our policy, others use opponent policies
                if player == 0:
                    with torch.no_grad():
                        regret_values = self.regret_net(state_tensor)[0].cpu().numpy()
                        # Mask illegal actions
                        mask = np.ones_like(regret_values) * float('-inf')
                        mask[legal_actions] = 0
                        masked_values = regret_values + mask
                        
                        # Add exploration
                        if random.random() < 0.1:
                            action = random.choice(legal_actions)
                        else:
                            action = np.argmax(masked_values)
                else:
                    # Use opponent policy
                    policy_idx = (player - 1) % len(opponent_policies)
                    opponent_policy = opponent_policies[policy_idx]
                    
                    if opponent_policy:
                        action_probs = opponent_policy.action_probabilities(state)
                        actions, probs = zip(*action_probs.items())
                        action = np.random.choice(actions, p=probs)
                    else:
                        # Random if no policy
                        action = random.choice(legal_actions)
                
                # Store transition for player 0 only
                if player == 0:
                    info_state = state.information_state_string(player)
                    trajectory.append({
                        'info_state': info_state,
                        'state': state.clone(),
                        'action': action,
                        'legal_actions': legal_actions,
                        'player': player,
                        'reward': 0,  # Placeholder
                        'done': False
                    })
                
                # Apply action
                state.apply_action(action)
                done = state.is_terminal()
            
            # Update rewards for trajectory
            if trajectory:
                returns = state.returns()
                player_return = returns[0]  # Only for player 0
                
                for transition in trajectory:
                    transition['reward'] = player_return
                    transition['done'] = True
                
                buffer.extend(trajectory)
        
        return buffer
