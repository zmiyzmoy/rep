import os
import time
import logging
import sys
import signal
import torch
import random
import numpy as np
from typing import List, Dict, Tuple, Union, Any
import pyspiel

def set_random_seed(seed: int):
    """Set random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    logging.info(f"Random seed set to {seed}")

def setup_logging(log_dir: str, name: str = "training"):
    """Set up logging to file and console."""
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"{name}_{int(time.time())}.log")
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler(sys.stdout)
        ]
    )
    logging.info(f"Logging set up to {log_path}")

def safe_save_model(model, optimizer, epoch, best_performance, path):
    """Safely save model checkpoint."""
    temp_path = path + ".tmp"
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_performance': best_performance
    }
    torch.save(checkpoint, temp_path)
    os.replace(temp_path, path)
    logging.info(f"Model saved to {path}")

def load_checkpoint(model, optimizer, path):
    """Load model checkpoint."""
    if not os.path.exists(path):
        logging.warning(f"No checkpoint found at {path}")
        return 0, float('-inf')
    
    checkpoint = torch.load(path, map_location=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    logging.info(f"Loaded checkpoint from {path} (epoch {checkpoint['epoch']})")
    return checkpoint['epoch'], checkpoint['best_performance']

def get_legal_actions(state):
    """Get legal actions from state."""
    if state.is_terminal():
        return []
    return state.legal_actions()

def softmax(x, temperature=1.0):
    """Compute softmax values for array x with temperature scaling."""
    x = np.array(x) / temperature
    x = x - np.max(x)  # Numerical stability
    exp_x = np.exp(x)
    return exp_x / np.sum(exp_x)

class MultiAgentGameRunner:
    """Utility class for running multi-agent games."""
    
    def __init__(self, game_name: str, num_players: int):
        self.game = pyspiel.load_game(game_name)
        self.num_players = num_players

    def run_game(self, policies: List[Any], temperature: float = 1.0):
        """Run a game with the provided policies."""
        state = self.game.new_initial_state()
        histories = [[] for _ in range(self.num_players)]
        
        while not state.is_terminal():
            if state.is_chance_node():
                outcomes = state.chance_outcomes()
                action_list, prob_list = zip(*outcomes)
                action = np.random.choice(action_list, p=prob_list)
                state.apply_action(action)
            else:
                player = state.current_player()
                legal_actions = state.legal_actions()
                
                # Get policy for current player
                policy = policies[player]
                
                # Apply action based on policy
                if hasattr(policy, 'action_probabilities'):
                    # OpenSpiel policy
                    probs = policy.action_probabilities(state)
                    actions, probs = zip(*[(a, p) for a, p in probs.items() if a in legal_actions])
                    if not actions:
                        action = legal_actions[0]
                    else:
                        probs = softmax(np.array(probs), temperature)
                        action = np.random.choice(actions, p=probs)
                elif callable(policy):
                    # Function policy
                    action = policy(state, legal_actions)
                else:
                    # Default random policy
                    action = random.choice(legal_actions)
                
                # Record action in history
                histories[player].append({
                    'state': state.clone(),
                    'action': action,
                    'legal_actions': legal_actions,
                    'info_state': state.information_state_string(player)
                })
                
                # Apply action to game state
                state.apply_action(action)
        
        # Get returns for all players
        returns = state.returns()
        
        return {
            'histories': histories,
            'returns': returns,
            'terminal_state': state
        }

def action_to_string(game, action):
    """Convert action to readable string."""
    if hasattr(game, 'action_to_string'):
        return game.action_to_string(action)
    return str(action)

def get_action_mask(state, legal_actions=None):
    """Create a boolean mask for legal actions."""
    if legal_actions is None:
        legal_actions = state.legal_actions()
    
    num_distinct_actions = state.game().num_distinct_actions()
    mask = np.zeros(num_distinct_actions, dtype=bool)
    mask[legal_actions] = True
    return mask

def handle_sigterm():
    """Set up SIGTERM signal handler for graceful shutdown."""
    def handler(signum, frame):
        logging.info("Received termination signal, shutting down gracefully...")
        sys.exit(0)
    
    signal.signal(signal.SIGTERM, handler)
    signal.signal(signal.SIGINT, handler)
    logging.info("Signal handlers set up for graceful shutdown")

class TournamentEvaluator:
    """Evaluate policies through tournament play."""
    
    def __init__(self, game_name: str, num_players: int, num_games: int = 100):
        self.game_runner = MultiAgentGameRunner(game_name, num_players)
        self.num_games = num_games
    
    def run_tournament(self, policies: List[Any]):
        """Run a tournament between policies."""
        num_policies = len(policies)
        results = np.zeros((num_policies, num_policies))
        
        for i in range(num_policies):
            for j in range(i+1, num_policies):
                # Run games between policies i and j
                i_score = 0
                j_score = 0
                
                for _ in range(self.num_games):
                    tournament_policies = [policies[i] if idx == 0 else policies[j] if idx == 1 else 
                                          random.choice([policies[i], policies[j]]) 
                                          for idx in range(self.game_runner.num_players)]
                    
                    game_result = self.game_runner.run_game(tournament_policies)
                    returns = game_result['returns']
                    
                    # Sum returns for each policy
                    for player_idx, policy_idx in enumerate(tournament_policies):
                        if policy_idx == policies[i]:
                            i_score += returns[player_idx]
                        elif policy_idx == policies[j]:
                            j_score += returns[player_idx]
                
                # Record normalized results
                total_score = max(1, abs(i_score) + abs(j_score))
                results[i, j] = i_score / total_score
                results[j, i] = j_score / total_score
        
        return results
