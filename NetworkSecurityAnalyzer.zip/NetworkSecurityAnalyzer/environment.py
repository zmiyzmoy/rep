import os
import logging
import numpy as np
import torch
import pyspiel
from typing import List, Dict, Tuple, Optional
from collections import deque
from open_spiel.python import policy as openspiel_policy

class PokerEnvironment:
    """Environment wrapper for Poker game using OpenSpiel."""
    
    def __init__(self, game_name: str, num_players: int, max_steps: int = 1000):
        self.game = pyspiel.load_game(game_name)
        self.num_players = num_players
        self.max_steps = max_steps
        self.step_counter = 0
        self.action_mapping = {a: i for i, a in enumerate(range(self.game.num_distinct_actions()))}
        self.reverse_action_mapping = {i: a for a, i in self.action_mapping.items()}
        logging.info(f"Poker Environment initialized with game: {game_name}")
        
    def reset(self):
        """Reset the environment to initial state."""
        self.state = self.game.new_initial_state()
        self.step_counter = 0
        self.history = []
        self.done = False
        
        # Handle chance node at the beginning
        while self.state.is_chance_node() and not self.state.is_terminal():
            outcomes = self.state.chance_outcomes()
            action_list, prob_list = zip(*outcomes)
            action = np.random.choice(action_list, p=prob_list)
            self.state.apply_action(action)
            
        return self.state

    def step(self, action):
        """Take an action in the environment."""
        if self.state.is_terminal():
            logging.warning("Attempting to step in a terminal state")
            return self.state, 0, True, {}
            
        self.history.append({
            'player': self.state.current_player(),
            'action': action,
            'info_state': self.state.information_state_string(self.state.current_player())
        })
        
        self.state.apply_action(action)
        self.step_counter += 1
        
        # Process chance nodes
        while self.state.is_chance_node() and not self.state.is_terminal():
            outcomes = self.state.chance_outcomes()
            action_list, prob_list = zip(*outcomes)
            action = np.random.choice(action_list, p=prob_list)
            self.state.apply_action(action)
        
        # Check if game is over
        self.done = self.state.is_terminal() or self.step_counter >= self.max_steps
        
        # Get rewards
        rewards = self.state.returns() if self.state.is_terminal() else [0] * self.num_players
        
        info = {
            'legal_actions': self.state.legal_actions() if not self.state.is_terminal() else [],
            'current_player': self.state.current_player() if not self.state.is_terminal() else -1,
            'history': self.history,
            'is_terminal': self.state.is_terminal()
        }
        
        return self.state, rewards, self.done, info
    
    def sample_action(self):
        """Sample a random legal action."""
        if self.state.is_terminal():
            return None
        return np.random.choice(self.state.legal_actions())
    
    def legal_actions_mask(self):
        """Get a binary mask of legal actions."""
        if self.state.is_terminal():
            return np.zeros(self.game.num_distinct_actions(), dtype=np.bool)
        
        mask = np.zeros(self.game.num_distinct_actions(), dtype=np.bool)
        mask[self.state.legal_actions()] = True
        return mask
    
    def get_current_player(self):
        """Get the current player index."""
        if self.state.is_terminal():
            return -1
        return self.state.current_player()
    
    def get_state(self):
        """Get the current state."""
        return self.state
    
    def get_info_state(self, player_id):
        """Get the information state for a specific player."""
        return self.state.information_state_string(player_id)
    
    def get_info_state_tensor(self, player_id):
        """Get the information state tensor for a specific player."""
        return self.state.information_state_tensor(player_id)

class TabularPolicy(openspiel_policy.Policy):
    """Tabular policy implementation for OpenSpiel."""
    
    def __init__(self, game, player_ids=None):
        super().__init__(game, player_ids)
        self.policy_table = {}
        self.default_policy = {}
    
    def action_probabilities(self, state, player_id=None):
        """Returns the policy for a specific state."""
        if state.is_terminal():
            return {}
        
        if state.is_chance_node():
            return {a: p for a, p in state.chance_outcomes()}
        
        info_state = state.information_state_string()
        legal_actions = state.legal_actions()
        
        if info_state in self.policy_table:
            probs = self.policy_table[info_state]
            # Filter to legal actions and normalize
            filtered_probs = {a: probs.get(a, 0) for a in legal_actions}
            if sum(filtered_probs.values()) > 0:
                # Normalize if there are positive probabilities
                norm = sum(filtered_probs.values())
                return {a: p/norm for a, p in filtered_probs.items()}
        
        # Default uniform policy
        num_legal = len(legal_actions)
        if num_legal > 0:
            return {a: 1.0 / num_legal for a in legal_actions}
        return {}
    
    def update(self, info_state, action_probs):
        """Update the policy for a given information state."""
        self.policy_table[info_state] = action_probs
    
    def get_policy_table(self):
        """Get the full policy table."""
        return self.policy_table
    
    def set_policy_table(self, table):
        """Set the policy table."""
        self.policy_table = table
        
    def clone(self):
        """Create a clone of this policy."""
        clone = TabularPolicy(self.game)
        clone.policy_table = dict(self.policy_table)
        return clone
    
    def serialize(self):
        """Serialize this policy to a string."""
        return str(self.policy_table)
    
    @classmethod
    def deserialize(cls, game, serialized):
        """Deserialize a policy from a string."""
        policy_obj = cls(game)
        policy_obj.policy_table = eval(serialized)
        return policy_obj

class TorchPolicy(openspiel_policy.Policy):
    """Neural network policy implementation using PyTorch."""
    
    def __init__(self, game, model, state_processor, temperature=1.0, player_ids=None):
        super().__init__(game, player_ids)
        self.model = model
        self.state_processor = state_processor
        self.temperature = temperature
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.model.eval()
    
    def action_probabilities(self, state, player_id=None):
        """Returns action probabilities for a given state."""
        if state.is_terminal():
            return {}
        
        if state.is_chance_node():
            return {a: p for a, p in state.chance_outcomes()}
        
        current_player = state.current_player() if player_id is None else player_id
        legal_actions = state.legal_actions()
        
        if not legal_actions:
            return {}
        
        # Process state for neural network
        processed_state = self.state_processor.process([state], [current_player])
        state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=self.device)
        
        with torch.no_grad():
            logits = self.model(state_tensor)[0].cpu().numpy()
        
        # Apply temperature and mask illegal actions
        temperature_logits = logits / self.temperature
        mask = np.ones_like(temperature_logits) * (-1e9)
        mask[legal_actions] = 0
        masked_logits = temperature_logits + mask
        
        # Calculate probabilities using softmax
        probabilities = np.exp(masked_logits - np.max(masked_logits))
        probabilities = probabilities / np.sum(probabilities)
        
        # Ensure the probability distribution sums to 1 (fix any numerical errors)
        probs_dict = {a: probabilities[a] for a in legal_actions}
        total_prob = sum(probs_dict.values())
        
        # If total probability doesn't sum close to 1, normalize again
        if abs(total_prob - 1.0) > 1e-6:
            for a in probs_dict:
                probs_dict[a] /= total_prob
                
        # If we only have one action, ensure 100% probability for that action
        if len(legal_actions) == 1:
            probs_dict = {legal_actions[0]: 1.0}
        
        return probs_dict
    
    def update_model(self, new_model):
        """Update the underlying model."""
        self.model.load_state_dict(new_model.state_dict())
        self.model.eval()
    
    def set_temperature(self, temperature):
        """Update the temperature parameter for exploration."""
        self.temperature = temperature
    
    def clone(self):
        """Create a clone of this policy."""
        return TorchPolicy(self.game, 
                          torch.jit.script(self.model) if not isinstance(self.model, torch.jit.ScriptModule) else self.model, 
                          self.state_processor, 
                          self.temperature,
                          self.player_ids)
