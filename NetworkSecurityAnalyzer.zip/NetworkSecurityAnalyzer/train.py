import os
import time
import logging
import sys
import signal
import argparse
import numpy as np
import torch
import pyspiel
import ray
from tqdm import tqdm
from collections import deque
from typing import List, Dict, Tuple, Optional

# Import project modules
from models import Config, RegretNet, StrategyNet, StateProcessor, OpponentStats, RewardNormalizer, PrioritizedReplayBuffer
from utils import set_random_seed, setup_logging, safe_save_model, TournamentEvaluator
from environment import PokerEnvironment, TabularPolicy, TorchPolicy
from psro import PSROSolver, PSROWorker

def parse_args():
    parser = argparse.ArgumentParser(description="Poker RL Training with PSRO")
    parser.add_argument('--base_dir', type=str, default='./poker', help='Base directory for models and logs')
    parser.add_argument('--num_iterations', type=int, default=20, help='Number of PSRO iterations')
    parser.add_argument('--num_workers', type=int, default=8, help='Number of parallel workers')
    parser.add_argument('--num_episodes', type=int, default=100, help='Number of episodes per BR training')
    parser.add_argument('--checkpoint_interval', type=int, default=300, help='Checkpoint interval in seconds')
    parser.add_argument('--resume', action='store_true', help='Resume from last checkpoint')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--eval_interval', type=int, default=5, help='Evaluation interval (iterations)')
    parser.add_argument('--log_level', type=str, default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='Logging level')
    return parser.parse_args()

def setup_environment(config):
    """Setup training environment and directories."""
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Setup logging
    log_level = getattr(logging, args.log_level)
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(config.LOG_DIR, f'training_{int(time.time())}.log')),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    # Setup signal handlers for graceful shutdown
    def signal_handler(sig, frame):
        logging.info("Received termination signal, shutting down gracefully...")
        if ray.is_initialized():
            ray.shutdown()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logging.info(f"Environment setup complete. Using device: {torch.device('cuda' if torch.cuda.is_available() else 'cpu')}")

def evaluate_policies(solver, config, num_games=100):
    """Evaluate current policies in a tournament."""
    evaluator = TournamentEvaluator(config.GAME_NAME, config.NUM_PLAYERS, num_games=num_games)
    
    # Get meta-strategy from solver
    policies = solver.strategy_pool
    meta_strategy = solver.meta_strategies
    
    logging.info(f"Running tournament evaluation with {len(policies)} policies...")
    
    # Run tournament between policies
    results = evaluator.run_tournament(policies)
    
    # Calculate expected payoffs under meta-strategy
    meta_payoff = 0
    for i, p_i in enumerate(meta_strategy):
        for j, p_j in enumerate(meta_strategy):
            meta_payoff += p_i * p_j * results[i, j]
    
    # Calculate exploitability if possible (may not be tractable for large games)
    exploit = "N/A"
    try:
        if len(policies) <= 2:  # Only attempt for small games
            exploit = exploitability.exploitability(solver.game, policies[0])
    except Exception as e:
        logging.warning(f"Could not compute exploitability: {e}")
    
    logging.info(f"Tournament results:\n{results}")
    logging.info(f"Meta-strategy expected payoff: {meta_payoff:.4f}")
    logging.info(f"Exploitability: {exploit}")
    
    return {
        'tournament_results': results,
        'meta_payoff': meta_payoff,
        'exploitability': exploit
    }

def main(args):
    # Initialize configuration
    config = Config()
    config.BASE_DIR = args.base_dir
    config.MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(config.BASE_DIR, 'models', 'psro_best.pt')
    config.LOG_DIR = os.path.join(config.BASE_DIR, 'logs')
    config.NUM_EPISODES = args.num_episodes
    config.NUM_WORKERS = args.num_workers
    config.CHECKPOINT_INTERVAL = args.checkpoint_interval
    
    # Setup environment
    setup_environment(config)
    
    # Set random seed
    set_random_seed(args.seed)
    
    # Initialize Ray for distributed processing
    if not ray.is_initialized():
        ray.init(ignore_reinit_error=True)
        logging.info("Ray initialized for distributed training")
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize PSRO solver
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint if resuming
    if args.resume:
        if solver.load_checkpoints():
            logging.info("Resuming from previous checkpoint")
        else:
            logging.warning("No checkpoint found, starting from scratch")
    
    # Initialize workers
    workers = [PSROWorker.remote(config, i) for i in range(config.NUM_WORKERS)]
    
    logging.info("Starting PSRO training...")
    
    # Run PSRO iterations
    for iteration in range(args.num_iterations):
        start_time = time.time()
        logging.info(f"Starting PSRO iteration {iteration+1}/{args.num_iterations}")
        
        # 1. Sample opponent strategy
        opponent_strategy = solver.sample_strategy_from_pool()
        
        # 2. Update workers with current model
        update_tasks = [
            worker.update_models.remote(
                solver.regret_net.state_dict(), 
                solver.strategy_net.state_dict()
            ) for worker in workers
        ]
        ray.get(update_tasks)
        
        # 3. Collect experience in parallel
        experience_tasks = [
            worker.collect_experience.remote(
                [opponent_strategy], config.STEPS_PER_WORKER
            ) for worker in workers
        ]
        
        all_experience = []
        for experience in ray.get(experience_tasks):
            all_experience.extend(experience)
        
        logging.info(f"Collected {len(all_experience)} transitions from {config.NUM_WORKERS} workers")
        
        # 4. Train models on collected experience
        solver._train_on_buffer(all_experience, batch_size=config.BATCH_SIZE, epochs=5)
        
        # 5. Extract policy from trained best response
        br_policy = solver.extract_policy_from_model()
        
        # 6. Add best response to strategy pool
        solver.add_strategy_to_pool(br_policy)
        
        # 7. Recompute meta-strategies
        solver.meta_strategies = solver.compute_meta_strategies()
        
        # 8. Periodic evaluation
        if (iteration + 1) % args.eval_interval == 0:
            eval_results = evaluate_policies(solver, config)
        
        # 9. Checkpoint
        if time.time() - start_time >= config.CHECKPOINT_INTERVAL:
            solver.save_checkpoints(f"iter_{iteration+1}")
        
        iteration_time = time.time() - start_time
        logging.info(f"Completed PSRO iteration {iteration+1} in {iteration_time:.2f} seconds")
        logging.info(f"Strategy pool size: {len(solver.strategy_pool)}")
        logging.info(f"Meta-strategies: {solver.meta_strategies}")
    
    # Final checkpoint and evaluation
    solver.save_checkpoints("final")
    evaluate_policies(solver, config, num_games=200)
    
    # Shutdown Ray
    ray.shutdown()
    logging.info("Training completed successfully")

if __name__ == "__main__":
    args = parse_args()
    main(args)
