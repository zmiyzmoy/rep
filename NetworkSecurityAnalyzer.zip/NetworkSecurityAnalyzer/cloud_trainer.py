#!/usr/bin/env python3
import os
import time
import json
import logging
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.amp import autocast
from torch.cuda.amp import GradScaler
import torch.multiprocessing as mp
import pyspiel
import ray
from tqdm.auto import tqdm
from collections import deque
from typing import List, Dict, Tuple, Optional, Any, Union

# Import project modules
from models import Config, RegretNet, StrategyNet, StateProcessor, OpponentStats
from utils import set_random_seed, setup_logging, MultiAgentGameRunner
from environment import PokerEnvironment, TabularPolicy, TorchPolicy
from psro import PSROSolver

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cloud_training.log'),
        logging.StreamHandler()
    ]
)

def parse_args():
    parser = argparse.ArgumentParser(description="Poker AI Training on Cloud")
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'export', 'inference'],
                        default='train', help='Operation mode')
    parser.add_argument('--base_dir', type=str, default='./poker', 
                        help='Base directory for models and logs')
    parser.add_argument('--num_iterations', type=int, default=100, 
                        help='Number of PSRO iterations')
    parser.add_argument('--num_episodes', type=int, default=10000, 
                        help='Number of episodes for training')
    parser.add_argument('--checkpoint', type=str, default='latest',
                        help='Checkpoint to load (latest, best, or specific path)')
    parser.add_argument('--seed', type=int, default=42, 
                        help='Random seed for reproducibility')
    parser.add_argument('--num_workers', type=int, default=8, 
                        help='Number of parallel workers')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose output')
    parser.add_argument('--input_file', type=str, help='JSON input file for inference mode')
    parser.add_argument('--output_file', type=str, help='JSON output file for inference results')
    parser.add_argument('--game_config', type=str, default='6max_nlh',
                        choices=['6max_nlh', '9max_nlh', 'hu_nlh'],
                        help='Game configuration')
    parser.add_argument('--stack_size', type=int, default=100,
                        help='Stack size in big blinds')
    parser.add_argument('--eval_interval', type=int, default=10,
                        help='Evaluate every N iterations')
    parser.add_argument('--save_interval', type=int, default=5,
                        help='Save checkpoints every N iterations')
    parser.add_argument('--checkpoint_dir', type=str, default=None,
                        help='Directory to save checkpoints')
    return parser.parse_args()

def init_config(args):
    """Initialize configuration with command line args."""
    config = Config()
    config.BASE_DIR = args.base_dir
    
    # Set model paths
    if args.checkpoint_dir:
        model_dir = args.checkpoint_dir
    else:
        model_dir = os.path.join(config.BASE_DIR, 'models')
    
    config.MODEL_PATH = os.path.join(model_dir, 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(model_dir, 'psro_best.pt')
    config.LOG_DIR = os.path.join(config.BASE_DIR, 'logs')
    config.KMEANS_PATH = os.path.join(model_dir, 'kmeans.joblib')
    
    # Set training parameters
    config.NUM_EPISODES = args.num_episodes
    config.NUM_WORKERS = args.num_workers
    config.BATCH_SIZE = 256 if torch.cuda.is_available() else 64
    config.LEARNING_RATE = 1e-4
    config.EVAL_INTERVAL = args.eval_interval
    config.SAVE_INTERVAL = args.save_interval
    
    # Configure game
    if args.game_config == '6max_nlh':
        config.NUM_PLAYERS = 6
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack={args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    elif args.game_config == '9max_nlh':
        config.NUM_PLAYERS = 9
        stacks = f"{args.stack_size} " * 9
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=9,numRounds=4,blind=0.5 1 1 1 1 1 1 1 1,raiseSize=0.10 0.20 0.40 0.80,stack={stacks.strip()},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    elif args.game_config == 'hu_nlh':
        config.NUM_PLAYERS = 2
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=2,numRounds=4,blind=1 2,raiseSize=0.10 0.20 0.40 0.80,stack={args.stack_size} {args.stack_size},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    
    # Create directories
    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(config.LOG_DIR, exist_ok=True)
    
    # Set log level
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.getLogger().setLevel(log_level)
    
    return config

def train_psro(args, config):
    """Run PSRO training optimized for cloud GPU."""
    # Set random seed
    set_random_seed(args.seed)
    
    # Check for GPU
    use_gpu = torch.cuda.is_available()
    if use_gpu:
        logging.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
        # Set optimized parameters for A100
        torch.backends.cudnn.benchmark = True
    else:
        logging.warning("GPU not available, using CPU.")
    
    # Initialize Ray for distributed processing
    if not ray.is_initialized():
        num_cpus = os.cpu_count()
        ray_init_kwargs = {
            "ignore_reinit_error": True,
            "num_cpus": num_cpus,
        }
        if use_gpu:
            ray_init_kwargs["num_gpus"] = 1
        ray.init(**ray_init_kwargs)
        logging.info(f"Ray initialized with {num_cpus} CPUs" + (", GPU enabled" if use_gpu else ""))
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize PSRO solver
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint if specified
    if args.checkpoint and args.checkpoint.lower() != 'none':
        if args.checkpoint.lower() == 'latest':
            if os.path.exists(config.MODEL_PATH + ".final"):
                solver.load_checkpoints("final")
                logging.info("Loaded latest checkpoint")
            else:
                logging.warning("No latest checkpoint found, initializing new model")
        elif args.checkpoint.lower() == 'best':
            if os.path.exists(config.BEST_MODEL_PATH):
                solver.load_checkpoints("best")
                logging.info("Loaded best checkpoint")
            else:
                logging.warning("No best checkpoint found, initializing new model")
        else:
            # Try to load specific checkpoint
            try:
                solver.load_checkpoints(args.checkpoint)
                logging.info(f"Loaded checkpoint: {args.checkpoint}")
            except:
                logging.warning(f"Failed to load checkpoint: {args.checkpoint}")
    
    # Metrics tracking
    best_exploitability = float('inf')
    metrics = {
        'exploitability': [],
        'policy_size': [],
        'training_time': [],
        'win_rates': []
    }
    
    # Run PSRO iterations
    logging.info(f"Starting PSRO training for {args.num_iterations} iterations...")
    start_time = time.time()
    last_checkpoint_time = start_time
    
    for iteration in range(args.num_iterations):
        iter_start_time = time.time()
        logging.info(f"===== Starting PSRO iteration {iteration+1}/{args.num_iterations} =====")
        
        # Run one PSRO iteration (train best response, add to pool, compute meta-strategy)
        solver.br_policy_iteration(num_iterations=1)
        
        # Calculate training time
        iter_time = time.time() - iter_start_time
        metrics['training_time'].append(iter_time)
        metrics['policy_size'].append(len(solver.strategy_pool))
        
        # Evaluate if needed
        if (iteration + 1) % config.EVAL_INTERVAL == 0:
            logging.info(f"Evaluating strategies at iteration {iteration+1}")
            
            # Evaluate against random agent
            win_rate = evaluate_against_random(solver, config, num_games=100)
            metrics['win_rates'].append(win_rate)
            
            # Try to compute exploitability if game is small enough
            try:
                if config.NUM_PLAYERS <= 2:  # Exploitability only valid for 2-player zero-sum games
                    game = pyspiel.load_game(config.GAME_NAME)
                    policy = TorchPolicy(game, solver.regret_net, state_processor)
                    from open_spiel.python.algorithms import exploitability
                    expl = exploitability.exploitability(game, policy)
                    metrics['exploitability'].append(expl)
                    logging.info(f"Exploitability: {expl:.6f}")
                    
                    # Save best model
                    if expl < best_exploitability:
                        best_exploitability = expl
                        solver.save_checkpoints("best")
                        logging.info(f"Saved new best model with exploitability: {expl:.6f}")
            except Exception as e:
                logging.warning(f"Could not compute exploitability: {e}")
        
        # Save checkpoint if needed
        if (iteration + 1) % config.SAVE_INTERVAL == 0:
            solver.save_checkpoints(f"iteration_{iteration+1}")
            logging.info(f"Saved checkpoint for iteration {iteration+1}")
        
        # Log progress
        logging.info(f"Iteration {iteration+1} completed in {iter_time:.2f}s")
        logging.info(f"Strategy pool size: {len(solver.strategy_pool)}")
        logging.info(f"Total time elapsed: {(time.time() - start_time)/60:.2f} minutes")
        
        # Save metrics
        with open(os.path.join(config.LOG_DIR, 'metrics.json'), 'w') as f:
            json.dump(metrics, f)
    
    # Final checkpoint
    solver.save_checkpoints("final")
    logging.info(f"PSRO training completed in {(time.time() - start_time)/3600:.2f} hours")
    
    # Shutdown Ray
    ray.shutdown()
    logging.info("PSRO training completed successfully")
    
    return solver

def evaluate_against_random(solver, config, num_games=100):
    """Evaluate against a random agent."""
    game = pyspiel.load_game(config.GAME_NAME)
    policy = TorchPolicy(game, solver.regret_net, solver.state_processor)
    random_policy = pyspiel.make_uniform_random_policy(game)
    
    wins = 0
    total = 0
    
    for _ in range(num_games):
        state = game.new_initial_state()
        while not state.is_terminal():
            if state.is_chance_node():
                outcomes = state.chance_outcomes()
                action_list, prob_list = zip(*outcomes)
                action = np.random.choice(action_list, p=prob_list)
                state.apply_action(action)
            else:
                current_player = state.current_player()
                if current_player == 0:  # Our AI
                    action_probs = policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    
                    # Ensure probabilities sum to 1
                    probs = np.array(probs)
                    probs_sum = probs.sum()
                    if abs(probs_sum - 1.0) > 1e-6:
                        probs = probs / probs_sum
                    
                    action = np.random.choice(actions, p=probs)
                else:  # Random opponent
                    action_probs = random_policy.action_probabilities(state)
                    actions, probs = zip(*action_probs.items())
                    action = np.random.choice(actions, p=probs)
                
                state.apply_action(action)
        
        # Get returns and check if our agent won
        returns = state.returns()
        if returns[0] > 0:
            wins += 1
        total += 1
    
    win_rate = wins / total if total > 0 else 0
    logging.info(f"Win rate against random: {win_rate:.4f}")
    return win_rate

def inference_from_json(args, config, model_path=None):
    """Run inference using a trained model on JSON input."""
    if not args.input_file:
        logging.error("Input file required for inference mode")
        return
    
    if not os.path.exists(args.input_file):
        logging.error(f"Input file not found: {args.input_file}")
        return
    
    # Load input data
    with open(args.input_file, 'r') as f:
        input_data = json.load(f)
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize solver and load checkpoint
    solver = PSROSolver(config, state_processor)
    
    if model_path:
        solver.load_checkpoints(model_path)
    elif args.checkpoint == 'best':
        solver.load_checkpoints("best")
    else:
        solver.load_checkpoints("final")
    
    # Process each hand scenario in the input data
    results = []
    for scenario in input_data:
        try:
            result = process_hand_scenario(scenario, solver, state_processor, config)
            results.append(result)
        except Exception as e:
            logging.error(f"Error processing scenario: {e}")
            results.append({"error": str(e), "input": scenario})
    
    # Save results
    output_file = args.output_file if args.output_file else "inference_results.json"
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    logging.info(f"Inference completed, results saved to {output_file}")
    return results

def process_hand_scenario(scenario, solver, state_processor, config):
    """Process a single poker hand scenario and return action recommendations."""
    # Extract scenario information
    try:
        hand_cards = scenario.get("hole_cards", [])  # e.g. ["Ah", "Kh"]
        board_cards = scenario.get("board", [])  # e.g. ["Jh", "Ts", "2c"]
        stack_sizes = scenario.get("stacks", [100] * config.NUM_PLAYERS)
        positions = scenario.get("positions", {})
        betting_history = scenario.get("betting_history", [])
        pot_size = scenario.get("pot_size", 0)
        player_position = scenario.get("hero_position", 0)
        
        # Convert card notation to internal representation
        hole_cards = convert_cards_to_internal(hand_cards)
        board = convert_cards_to_internal(board_cards)
        
        # Create game state from scenario
        game = pyspiel.load_game(config.GAME_NAME)
        state = create_state_from_scenario(game, hole_cards, board, betting_history, 
                                          stack_sizes, player_position)
        
        # Get legal actions
        legal_actions = state.legal_actions()
        
        # Use the trained model to get action probabilities
        policy = TorchPolicy(game, solver.regret_net, state_processor)
        action_probs = policy.action_probabilities(state)
        
        # Convert to readable format
        readable_actions = []
        for action, prob in action_probs.items():
            action_type = "fold"
            if action == 1:
                action_type = "call"
            elif action == 2:
                action_type = "raise_half_pot"
            elif action == 3:
                action_type = "raise_pot"
            
            readable_actions.append({
                "action": action_type,
                "probability": float(prob),
                "ev": float(predict_ev_for_action(solver, state, action, state_processor))
            })
        
        # Sort by EV
        readable_actions.sort(key=lambda x: x["ev"], reverse=True)
        
        return {
            "hole_cards": hand_cards,
            "board": board_cards,
            "pot_size": pot_size,
            "hero_position": player_position,
            "recommendations": readable_actions,
            "best_action": readable_actions[0]["action"] if readable_actions else None,
            "hand_strength": calculate_hand_strength(hole_cards, board_cards)
        }
    except Exception as e:
        logging.error(f"Error processing scenario: {e}")
        return {"error": str(e), "input": scenario}

def predict_ev_for_action(solver, state, action, state_processor):
    """Predict the expected value for a specific action."""
    # Process state
    player = state.current_player()
    processed_state = state_processor.process([state], [player])
    state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=solver.device)
    
    # Get regret values (proxy for expected values)
    with torch.no_grad():
        regret_values = solver.regret_net(state_tensor)[0].cpu().numpy()
    
    return regret_values[action]

def convert_cards_to_internal(cards):
    """Convert human readable cards (e.g., 'Ah') to internal representation."""
    if not cards:
        return []
    
    rank_map = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, 
                '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
    suit_map = {'c': 0, 'd': 1, 'h': 2, 's': 3}
    
    result = []
    for card in cards:
        if len(card) != 2:
            raise ValueError(f"Invalid card format: {card}")
        
        rank = card[0].upper()
        suit = card[1].lower()
        
        if rank not in rank_map:
            raise ValueError(f"Invalid rank: {rank}")
        if suit not in suit_map:
            raise ValueError(f"Invalid suit: {suit}")
        
        # Convert to OpenSpiel internal format
        internal_card = rank_map[rank] + suit_map[suit] * 13
        result.append(internal_card)
    
    return result

def create_state_from_scenario(game, hole_cards, board, betting_history, stacks, player_position):
    """Create a game state from scenario information."""
    # This is a simplified implementation - in practice, you would need
    # to implement a more complex function to build the exact game state
    # from the provided scenario
    
    # For now, we'll start with a new state and apply actions to reach 
    # the desired state (this is a placeholder)
    state = game.new_initial_state()
    
    # TODO: Implement full state reconstruction from scenario
    # This would involve setting up cards and applying betting actions
    
    return state

def calculate_hand_strength(hole_cards, board_cards):
    """Calculate the strength of a poker hand (simplified)."""
    # This is a placeholder - in a real implementation, you would compute
    # the actual poker hand strength
    return 0.5  # Placeholder value

def create_export_model(args, config):
    """Export a trained model for deployment."""
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize solver and load checkpoint
    solver = PSROSolver(config, state_processor)
    
    if args.checkpoint == 'best':
        solver.load_checkpoints("best")
    else:
        solver.load_checkpoints("final")
    
    # Export model to a deployable format
    export_path = os.path.join(config.BASE_DIR, 'exported_model')
    os.makedirs(export_path, exist_ok=True)
    
    # Save the models in TorchScript format for deployment
    regret_net_scripted = torch.jit.script(solver.regret_net)
    strategy_net_scripted = torch.jit.script(solver.strategy_net)
    
    regret_net_scripted.save(os.path.join(export_path, 'regret_net.pt'))
    strategy_net_scripted.save(os.path.join(export_path, 'strategy_net.pt'))
    
    # Save metadata
    metadata = {
        'game_config': args.game_config,
        'stack_size': args.stack_size,
        'state_size': state_processor.state_size,
        'num_actions': solver.num_actions,
        'export_date': time.strftime('%Y-%m-%d %H:%M:%S'),
        'model_version': '1.0'
    }
    
    with open(os.path.join(export_path, 'metadata.json'), 'w') as f:
        json.dump(metadata, f, indent=2)
    
    logging.info(f"Model exported to {export_path}")
    return export_path

def main():
    args = parse_args()
    config = init_config(args)
    
    # Register signal handlers for graceful shutdown
    import signal
    import sys
    
    def signal_handler(sig, frame):
        logging.info("Received termination signal, shutting down gracefully...")
        if ray.is_initialized():
            ray.shutdown()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run in selected mode
    if args.mode == 'train':
        train_psro(args, config)
    elif args.mode == 'eval':
        # Initialize state processor
        state_processor = StateProcessor(config)
        
        # Initialize solver and load checkpoint
        solver = PSROSolver(config, state_processor)
        
        if args.checkpoint == 'best':
            solver.load_checkpoints("best")
        else:
            solver.load_checkpoints("final")
        
        win_rate = evaluate_against_random(solver, config, num_games=1000)
        logging.info(f"Evaluation win rate: {win_rate:.4f}")
    elif args.mode == 'export':
        export_path = create_export_model(args, config)
        logging.info(f"Model exported to {export_path}")
    elif args.mode == 'inference':
        inference_from_json(args, config)
    else:
        logging.error(f"Unknown mode: {args.mode}")

if __name__ == "__main__":
    main()