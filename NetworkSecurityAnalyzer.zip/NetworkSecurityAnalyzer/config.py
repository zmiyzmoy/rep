import os
import argparse
import logging
import sys

# Настройка логирования
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('training_output.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

# Конфигурация
class Config:
    def __init__(self):
        parser = argparse.ArgumentParser(description="Poker RL Training")
        parser.add_argument('--base_dir', type=str, default='./poker', help='Base directory for models and logs')
        parser.add_argument('--num_episodes', type=int, default=10, help='Number of episodes per training iteration')
        parser.add_argument('--batch_size', type=int, default=64, help='Batch size for training')
        parser.add_argument('--buffer_capacity', type=int, default=10000, help='Capacity of experience replay buffer')
        parser.add_argument('--num_workers', type=int, default=8, help='Number of parallel workers')
        parser.add_argument('--lr', type=float, default=1e-4, help='Learning rate')
        parser.add_argument('--log_freq', type=int, default=10, help='Logging frequency')
        parser.add_argument('--test_interval', type=int, default=50, help='Testing interval')
        parser.add_argument('--num_buckets', type=int, default=50, help='Number of card buckets')
        args = parser.parse_args()

        self.BASE_DIR = args.base_dir
        self.MODEL_PATH = os.path.join(self.BASE_DIR, 'models', 'psro_model.pt')
        self.BEST_MODEL_PATH = os.path.join(self.BASE_DIR, 'models', 'psro_best.pt')
        self.LOG_DIR = os.path.join(self.BASE_DIR, 'logs')
        self.KMEANS_PATH = os.path.join(self.BASE_DIR, 'models', 'kmeans.joblib')
        self.NUM_EPISODES = args.num_episodes
        self.BATCH_SIZE = args.batch_size
        self.GAMMA = 0.96
        self.BUFFER_CAPACITY = args.buffer_capacity
        self.NUM_WORKERS = args.num_workers
        self.STEPS_PER_WORKER = 500
        self.SELFPLAY_UPDATE_FREQ = 50
        self.LOG_FREQ = args.log_freq
        self.TEST_INTERVAL = args.test_interval
        self.LEARNING_RATE = args.lr
        self.NUM_PLAYERS = 6
        self.GRAD_CLIP_VALUE = 5.0
        self.CHECKPOINT_INTERVAL = 300  # Секунды
        self.NUM_BUCKETS = args.num_buckets
        self.BB = 2
        self.MAX_STRATEGY_POOL = 10
        self.MAX_DICT_SIZE = 10000
        self.REWARD_NORMALIZATION = 'stack'
        self.GAME_NAME = "universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack=100 100 100 100 100 100,numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
        self.NASH_CONV_ITERS = 1000
        self.META_STRATEGY_METHOD = 'uniform'
        self.META_STRATEGY_ALPHA = 0.5
        self.EPSILON_START = 1.0
        self.EPSILON_END = 0.05
        self.EPSILON_DECAY = 10000
        self.PRIORITY_ALPHA = 0.6
        self.PRIORITY_BETA_START = 0.4
        self.PRIORITY_BETA_END = 1.0
        self.PRIORITY_BETA_STEPS = 100000
        self.AMP_ENABLED = True  # Mixed precision training
        self.MAX_GRAD_NORM = 10.0
