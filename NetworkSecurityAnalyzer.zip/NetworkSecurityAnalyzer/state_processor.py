import os
import numpy as np
import torch
from typing import List, Tuple, Dict, Optional
import logging
import joblib
from sklearn.cluster import KMeans
from models import CardEmbedding
from config import Config

config = Config()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class OpponentStats:
    def __init__(self):
        self.stats = {i: {
            'vpip': 0, 'pfr': 0, 'af': 0, 'hands': 0, 'folds': 0, 'calls': 0, 'raises': 0, 'last_bet': 0,
            'fold_to_cbet': 0, 'cbet_opp': 0, 'fold_to_3bet': 0, '3bet_opp': 0
        } for i in range(config.NUM_PLAYERS)}
        logging.info("OpponentStats initialized")
        
    def update(self, player_id: int, action_type: str, round_idx: int = 0, is_aggressor: bool = False):
        stats = self.stats[player_id]
        stats['hands'] += 1
        
        if action_type == 'fold':
            stats['folds'] += 1
        elif action_type == 'call':
            stats['calls'] += 1
            if round_idx == 0:  # Preflop
                stats['vpip'] = (stats['vpip'] * (stats['hands'] - 1) + 1) / stats['hands']
        elif action_type == 'raise':
            stats['raises'] += 1
            if round_idx == 0:  # Preflop
                stats['vpip'] = (stats['vpip'] * (stats['hands'] - 1) + 1) / stats['hands']
                stats['pfr'] = (stats['pfr'] * (stats['hands'] - 1) + 1) / stats['hands']
        
        # Update aggression factor
        if stats['calls'] + stats['folds'] > 0:
            stats['af'] = stats['raises'] / (stats['calls'] + stats['folds'])
            
    def get_features(self, player_id: int) -> List[float]:
        stats = self.stats[player_id]
        return [
            stats['vpip'], 
            stats['pfr'], 
            stats['af'], 
            stats['fold_to_cbet'] / max(1, stats['cbet_opp']),
            stats['fold_to_3bet'] / max(1, stats['3bet_opp'])
        ]

class StateProcessor:
    def __init__(self):
        self.card_embedding = CardEmbedding()
        self.buckets = self._load_or_precompute_buckets()
        self.state_size = config.NUM_BUCKETS + config.NUM_PLAYERS * 3 + 4 + 5
        self.cache = {}
        self.max_cache_size = config.MAX_DICT_SIZE
        logging.info(f"StateProcessor initialized, state_size={self.state_size}")

    def _load_or_precompute_buckets(self):
        if os.path.exists(config.KMEANS_PATH):
            buckets = joblib.load(config.KMEANS_PATH)
            logging.info(f"Loaded buckets from {config.KMEANS_PATH}")
            return buckets
            
        os.makedirs(os.path.dirname(config.KMEANS_PATH), exist_ok=True)
        logging.info("Precomputing card buckets...")
        all_hands = []
        for r1 in range(13):
            for r2 in range(r1, 13):
                for suited in [0, 1]:
                    hand = [r1 + suited * 13, r2 + suited * 13]
                    embedding = self.card_embedding(hand).cpu().detach().numpy().astype(np.float32)
                    all_hands.append(embedding)
                    
        kmeans = KMeans(n_clusters=config.NUM_BUCKETS, random_state=42, n_init=10).fit(np.array(all_hands, dtype=np.float32))
        joblib.dump(kmeans, config.KMEANS_PATH)
        logging.info(f"Buckets computed and saved to {config.KMEANS_PATH}")
        return kmeans

    def process(self, states: List, player_ids: List[int], bets: List[List[float]] = None, 
                stacks: List[List[float]] = None, stages: List[List[int]] = None, 
                opponent_stats: Optional[OpponentStats] = None) -> np.ndarray:
        batch_size = len(states)
        if bets is None:
            bets = [[0] * config.NUM_PLAYERS] * batch_size
        if stacks is None:
            stacks = [[100] * config.NUM_PLAYERS] * batch_size
        if stages is None:
            stages = [[0, 0, 0, 0]] * batch_size

        # Check cache for processed states
        state_keys = [f"{s.information_state_string(pid)}_{pid}_{tuple(b)}_{tuple(stk)}" 
                      for s, pid, b, stk in zip(states, player_ids, bets, stacks)]
        cached = [self.cache.get(key) for key in state_keys]
        if all(c is not None for c in cached):
            return np.array(cached, dtype=np.float32)

        # Process information states
        info_states = [s.information_state_tensor(pid) for s, pid in zip(states, player_ids)]
        cards_batch = []
        for info in info_states:
            private_cards = [int(i) for i, c in enumerate(info[:52]) if c > 0][:2]
            if not private_cards:
                private_cards = [0, 1]
            elif len(private_cards) < 2:
                private_cards.extend([1] * (2 - len(private_cards)))
            cards_batch.append(private_cards)

        # Get card embeddings and predict buckets
        card_embs = torch.stack([self.card_embedding(cards) for cards in cards_batch]).cpu().detach().numpy().astype(np.float32)
        bucket_idxs = self.buckets.predict(card_embs)
        bucket_one_hot = np.zeros((batch_size, config.NUM_BUCKETS), dtype=np.float32)
        bucket_one_hot[np.arange(batch_size), bucket_idxs] = 1.0

        # Normalize bets and stacks
        bets_norm = np.array(bets, dtype=np.float32) / (np.array(stacks, dtype=np.float32) + 1e-8)
        stacks_norm = np.array(stacks, dtype=np.float32) / 100.0
        
        # Calculate pot and stack-to-pot ratios
        pots = np.array([sum(b) for b in bets], dtype=np.float32)
        sprs = np.array([stk[pid] / pot if pot > 0 else 10.0 for stk, pid, pot in zip(stacks, player_ids, pots)], dtype=np.float32)
        
        # Position information
        positions = np.array([(pid - s.current_player()) % config.NUM_PLAYERS / config.NUM_PLAYERS 
                             for s, pid in zip(states, player_ids)], dtype=np.float32)
        
        # Action history
        action_history = np.array([([0] * config.NUM_PLAYERS if not hasattr(s, 'action_history') else 
                                   [min(h, 4) for h in s.action_history()[-config.NUM_PLAYERS:]]) 
                                   for s in states], dtype=np.float32)

        # Opponent stats if available
        opponent_features = np.zeros((batch_size, 3), dtype=np.float32)
        if opponent_stats is not None:
            for i, (s, pid) in enumerate(zip(states, player_ids)):
                curr_player = s.current_player()
                if curr_player != pid and curr_player < config.NUM_PLAYERS:
                    opp_stats = opponent_stats.get_features(curr_player)
                    opponent_features[i, :3] = opp_stats[:3]  # Just use first 3 features

        # Combine all features
        processed = np.concatenate([
            bucket_one_hot, 
            bets_norm, 
            stacks_norm, 
            action_history, 
            np.array(stages, dtype=np.float32),
            np.array([sprs, positions], dtype=np.float32).T,
            opponent_features
        ], axis=1).astype(np.float32)

        # Validate and cache
        if np.any(np.isnan(processed)) or np.any(np.isinf(processed)):
            logging.error(f"NaN/Inf in processed: {processed}")
            raise ValueError("Invalid state processing detected")

        if len(self.cache) >= self.max_cache_size:
            self.cache.clear()
        for key, proc in zip(state_keys, processed):
            self.cache[key] = proc
            
        return processed

    def get_state_size(self):
        return self.state_size
