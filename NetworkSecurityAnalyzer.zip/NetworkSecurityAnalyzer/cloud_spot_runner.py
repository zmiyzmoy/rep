#!/usr/bin/env python3
import os
import time
import json
import signal
import logging
import argparse
import subprocess
import sys
import requests
from datetime import datetime
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cloud_spot.log'),
        logging.StreamHandler()
    ]
)

def parse_args():
    parser = argparse.ArgumentParser(description="Poker AI Training on Google Cloud Spot Instance")
    parser.add_argument('--checkpoint_dir', type=str, default='./poker/checkpoints',
                        help='Directory to store checkpoints')
    parser.add_argument('--checkpoint_interval', type=int, default=15,
                        help='Minutes between checkpoints')
    parser.add_argument('--total_episodes', type=int, default=100000,
                        help='Total episodes to train for')
    parser.add_argument('--bucket', type=str, help='GCS bucket to sync checkpoints')
    parser.add_argument('--project', type=str, help='GCP project ID')
    parser.add_argument('--no_shutdown', action='store_true', 
                        help='Do not shutdown instance on completion')
    parser.add_argument('--status_url', type=str, 
                        help='URL to send status updates to (optional)')
    return parser.parse_args()

def check_for_preemption(interval=5):
    """
    Check for preemption notification on Google Cloud.
    On spot VMs, a signal file appears before preemption.
    """
    while True:
        try:
            # Check for preemption notice in metadata server
            url = "http://metadata.google.internal/computeMetadata/v1/instance/preempted"
            headers = {"Metadata-Flavor": "Google"}
            response = requests.get(url, headers=headers, timeout=2)
            
            # If we're being preempted (response content will be "TRUE")
            if response.text.strip().upper() == "TRUE":
                logging.warning("Preemption notice received! Initiating graceful shutdown...")
                # Initiate graceful shutdown
                os.kill(os.getpid(), signal.SIGTERM)
                return
        except Exception as e:
            # If we're not on GCP or there's an error, don't worry about it
            pass
            
        # Sleep before next check
        time.sleep(interval)

def sync_to_gcs(local_dir, bucket, direction="upload"):
    """Sync checkpoint files to/from GCS bucket"""
    if not bucket:
        logging.warning("No GCS bucket specified, skipping sync")
        return False
    
    try:
        if direction == "upload":
            cmd = f"gsutil -m rsync -r {local_dir} gs://{bucket}/checkpoints/"
        else:  # download
            cmd = f"gsutil -m rsync -r gs://{bucket}/checkpoints/ {local_dir}"
        
        logging.info(f"Running: {cmd}")
        result = subprocess.run(cmd, shell=True, check=True, 
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logging.info(f"GCS sync completed: {result.stdout.decode()}")
        return True
    except subprocess.CalledProcessError as e:
        logging.error(f"GCS sync failed: {e.stderr.decode()}")
        return False

def send_status_update(status_url, data):
    """Send status update to a monitoring endpoint"""
    if not status_url:
        return
    
    try:
        response = requests.post(
            status_url,
            json=data,
            timeout=10
        )
        response.raise_for_status()
        logging.info(f"Status update sent: {response.status_code}")
    except Exception as e:
        logging.error(f"Failed to send status update: {e}")

def shutdown_instance(project_id):
    """Shut down this instance"""
    if not project_id:
        logging.warning("No project ID specified, cannot shutdown instance")
        return False
    
    try:
        # Get instance name and zone
        name_url = "http://metadata.google.internal/computeMetadata/v1/instance/name"
        zone_url = "http://metadata.google.internal/computeMetadata/v1/instance/zone"
        headers = {"Metadata-Flavor": "Google"}
        
        instance_name = requests.get(name_url, headers=headers).text
        zone = requests.get(zone_url, headers=headers).text.split('/')[-1]
        
        # Use Google Cloud SDK to stop instance
        cmd = f"gcloud compute instances stop {instance_name} --zone={zone} --project={project_id}"
        logging.info(f"Shutting down instance: {cmd}")
        
        result = subprocess.run(cmd, shell=True, check=True)
        return True
    except Exception as e:
        logging.error(f"Failed to shutdown instance: {e}")
        return False

def main():
    args = parse_args()
    
    # Create checkpoint directory
    os.makedirs(args.checkpoint_dir, exist_ok=True)
    
    # Start preemption monitoring thread
    preemption_thread = threading.Thread(target=check_for_preemption, daemon=True)
    preemption_thread.start()
    
    # Try to download any existing checkpoints
    if args.bucket:
        sync_to_gcs(args.checkpoint_dir, args.bucket, direction="download")
    
    # Find most recent checkpoint
    latest_checkpoint = "latest"
    checkpoints = []
    try:
        checkpoint_files = [f for f in os.listdir(args.checkpoint_dir) 
                           if f.endswith('.pt.final') or f.endswith('.pt.best')]
        if checkpoint_files:
            checkpoint_times = [(f, os.path.getmtime(os.path.join(args.checkpoint_dir, f))) 
                               for f in checkpoint_files]
            latest_file, _ = max(checkpoint_times, key=lambda x: x[1])
            latest_checkpoint = os.path.splitext(os.path.splitext(latest_file)[0])[0]
            logging.info(f"Found latest checkpoint: {latest_checkpoint}")
    except Exception as e:
        logging.warning(f"Could not determine latest checkpoint: {e}")
    
    # Define signal handler for graceful shutdown
    def signal_handler(signum, frame):
        logging.info("Received termination signal, saving checkpoint...")
        
        # Save checkpoint (kill current training process first)
        if training_process.poll() is None:
            training_process.terminate()
            training_process.wait()
        
        # Sync to GCS
        if args.bucket:
            sync_to_gcs(args.checkpoint_dir, args.bucket, direction="upload")
        
        # Send final status update
        if args.status_url:
            send_status_update(args.status_url, {
                "status": "stopped",
                "timestamp": datetime.now().isoformat(),
                "reason": "signal",
                "checkpoint": latest_checkpoint
            })
        
        # Exit
        sys.exit(0)
    
    # Register signal handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    # Determine training command based on most recent checkpoint
    cmd = [
        "python", "cloud_trainer.py",
        "--mode", "train",
        "--checkpoint_dir", args.checkpoint_dir,
        "--num_episodes", str(args.total_episodes),
        "--num_workers", "16",  # Optimize for A100
        "--checkpoint", latest_checkpoint,
        "--verbose",
        "--save_interval", "1"  # Save frequently
    ]
    
    logging.info(f"Starting training: {' '.join(cmd)}")
    
    # Send initial status update
    if args.status_url:
        send_status_update(args.status_url, {
            "status": "started",
            "timestamp": datetime.now().isoformat(),
            "checkpoint": latest_checkpoint,
            "total_episodes": args.total_episodes
        })
    
    # Run training with regular checkpointing
    start_time = time.time()
    last_checkpoint_time = start_time
    training_process = None
    
    try:
        while True:
            # Start training process
            training_process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
                universal_newlines=True, bufsize=1
            )
            
            # Monitor and checkpoint
            line_buffer = []
            last_progress = 0
            completion_detected = False
            
            for line in iter(training_process.stdout.readline, ''):
                # Print and store output
                print(line, end='')
                line_buffer.append(line)
                if len(line_buffer) > 1000:
                    line_buffer.pop(0)
                
                # Check for progress indicators
                if "Iteration" in line and "completed" in line:
                    try:
                        # Extract iteration number
                        parts = line.split("Iteration ")[1].split("/")[0]
                        current_iter = int(parts)
                        last_progress = current_iter
                    except:
                        pass
                
                # Check for completion
                if "PSRO training completed successfully" in line:
                    completion_detected = True
                
                # Check if it's time to checkpoint
                current_time = time.time()
                if (current_time - last_checkpoint_time) >= (args.checkpoint_interval * 60):
                    logging.info("Checkpointing...")
                    
                    # Save checkpoint (by terminating process - it will auto-save)
                    training_process.terminate()
                    training_process.wait()
                    
                    # Sync checkpoint to GCS
                    if args.bucket:
                        sync_to_gcs(args.checkpoint_dir, args.bucket, direction="upload")
                    
                    # Send status update
                    if args.status_url:
                        send_status_update(args.status_url, {
                            "status": "running",
                            "timestamp": datetime.now().isoformat(),
                            "iteration": last_progress,
                            "runtime": (current_time - start_time) / 3600  # hours
                        })
                    
                    # Restart training process
                    last_checkpoint_time = current_time
                    break
            
            # Check if process completed naturally
            return_code = training_process.wait()
            if return_code == 0 and completion_detected:
                logging.info("Training completed successfully!")
                break
            elif return_code != 0 and not completion_detected:
                logging.error(f"Training process failed with code {return_code}")
                # Try to extract last error message
                error_msg = "Unknown error"
                for line in reversed(line_buffer):
                    if "Error" in line or "Exception" in line:
                        error_msg = line.strip()
                        break
                
                logging.error(f"Last error: {error_msg}")
                
                # Send error status
                if args.status_url:
                    send_status_update(args.status_url, {
                        "status": "error",
                        "timestamp": datetime.now().isoformat(),
                        "error": error_msg,
                        "exit_code": return_code
                    })
                
                # Wait before retrying
                time.sleep(60)
    finally:
        # Final sync to GCS
        if args.bucket:
            sync_to_gcs(args.checkpoint_dir, args.bucket, direction="upload")
        
        # Send completion status
        if args.status_url:
            send_status_update(args.status_url, {
                "status": "completed",
                "timestamp": datetime.now().isoformat(),
                "total_runtime": (time.time() - start_time) / 3600  # hours
            })
        
        # Shutdown instance if requested
        if not args.no_shutdown and args.project:
            shutdown_instance(args.project)

if __name__ == "__main__":
    main()