#!/usr/bin/env python3
import os
import json
import argparse
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import imageio
from datetime import datetime
from typing import Dict, List, Tuple, Any, Optional

def parse_args():
    parser = argparse.ArgumentParser(description="Visualize Poker AI Learning Curves")
    parser.add_argument('--metrics_file', type=str, default='./poker/logs/metrics.json',
                        help='Path to metrics JSON file')
    parser.add_argument('--output_dir', type=str, default='./poker/analysis',
                        help='Directory to save visualizations')
    parser.add_argument('--animate', action='store_true', default=True,
                        help='Generate animated learning curves')
    parser.add_argument('--milestones', type=str, default=None,
                        help='Path to milestones JSON file (format: {"iteration": description})')
    parser.add_argument('--gif_fps', type=int, default=4,
                        help='Frames per second for animated GIFs')
    parser.add_argument('--comparison', type=str, default=None,
                        help='Path to comparison metrics JSON file to overlay')
    parser.add_argument('--window_size', type=int, default=5,
                        help='Window size for smoothing metrics')
    return parser.parse_args()

def load_metrics(metrics_file: str) -> Optional[Dict[str, List[float]]]:
    """Load metrics from JSON file."""
    if not os.path.exists(metrics_file):
        print(f"Metrics file not found: {metrics_file}")
        return None
    
    try:
        with open(metrics_file, 'r') as f:
            metrics = json.load(f)
        return metrics
    except Exception as e:
        print(f"Error loading metrics: {e}")
        return None

def load_milestones(milestones_file: str) -> Optional[Dict[int, str]]:
    """Load milestone markers from JSON file."""
    if not milestones_file or not os.path.exists(milestones_file):
        return None
    
    try:
        with open(milestones_file, 'r') as f:
            milestones = json.load(f)
        
        # Convert keys to integers
        return {int(k): v for k, v in milestones.items()}
    except Exception as e:
        print(f"Error loading milestones: {e}")
        return None

def smooth_curve(values: List[float], window_size: int = 5) -> List[float]:
    """Apply moving average smoothing to a curve."""
    if len(values) < window_size:
        return values
    
    padded = np.pad(values, (window_size//2, window_size//2), mode='edge')
    smoothed = np.convolve(padded, np.ones(window_size)/window_size, mode='valid')
    
    # Ensure the smoothed array is the same length as the input array
    return smoothed[:len(values)].tolist()

def generate_static_plots(metrics: Dict[str, List[float]], 
                         milestones: Optional[Dict[int, str]], 
                         output_dir: str,
                         comparison_metrics: Optional[Dict[str, List[float]]] = None,
                         window_size: int = 5):
    """Generate static plots of learning curves with milestone markers."""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Define metrics to plot
    plot_configs = {
        'win_rates': {
            'title': 'Win Rate vs Random Agent',
            'ylabel': 'Win Rate',
            'ylim': (0, 1),
            'smooth': True
        },
        'exploitability': {
            'title': 'Exploitability',
            'ylabel': 'Exploitability',
            'yscale': 'log',
            'smooth': True
        },
        'training_time': {
            'title': 'Training Time per Iteration',
            'ylabel': 'Time (seconds)',
            'smooth': False
        },
        'policy_size': {
            'title': 'Strategy Pool Size',
            'ylabel': 'Number of Strategies',
            'smooth': False
        },
        'losses': {
            'title': 'Training Loss',
            'ylabel': 'Loss',
            'smooth': True
        }
    }
    
    # Create plots for each metric
    for metric_name, config in plot_configs.items():
        if metric_name not in metrics or not metrics[metric_name]:
            continue
        
        plt.figure(figsize=(12, 7))
        
        # Extract and potentially smooth the values
        values = metrics[metric_name]
        
        if config.get('smooth', False) and len(values) > window_size:
            smoothed_values = smooth_curve(values, window_size)
            x = list(range(len(values)))
            plt.plot(x, values, 'o-', alpha=0.4, label=f'Raw Values')
            plt.plot(x, smoothed_values, '-', linewidth=2, label=f'Smoothed (window={window_size})')
        else:
            x = list(range(len(values)))
            plt.plot(x, values, 'o-', linewidth=2, label='Training Progress')
        
        # Plot comparison if provided
        if comparison_metrics and metric_name in comparison_metrics and comparison_metrics[metric_name]:
            comp_values = comparison_metrics[metric_name]
            comp_x = list(range(len(comp_values)))
            
            if config.get('smooth', False) and len(comp_values) > window_size:
                smoothed_comp = smooth_curve(comp_values, window_size)
                plt.plot(comp_x, comp_values, 's-', alpha=0.3, label='Comparison Raw')
                plt.plot(comp_x, smoothed_comp, '-', linewidth=2, label='Comparison Smoothed')
            else:
                plt.plot(comp_x, comp_values, 's-', linewidth=2, label='Comparison')
        
        # Add milestone markers
        if milestones:
            for iteration, description in milestones.items():
                if 0 <= iteration < len(values):
                    plt.axvline(x=iteration, color='r', linestyle='--', alpha=0.5)
                    plt.text(iteration, plt.ylim()[0] + 0.02 * (plt.ylim()[1] - plt.ylim()[0]), 
                            f"  {description}", rotation=90, verticalalignment='bottom')
        
        # Configure plot
        plt.title(config['title'])
        plt.xlabel('Iteration')
        plt.ylabel(config['ylabel'])
        if 'ylim' in config:
            plt.ylim(config['ylim'])
        if 'yscale' in config:
            plt.yscale(config['yscale'])
        plt.grid(True, alpha=0.3)
        plt.legend()
        
        # Add date and time
        plt.figtext(0.02, 0.02, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 
                   fontsize=8, alpha=0.7)
        
        # Save figure
        output_path = os.path.join(output_dir, f"{metric_name}_curve.png")
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Saved plot to {output_path}")

def generate_animated_learning_curves(metrics: Dict[str, List[float]],
                                     milestones: Optional[Dict[int, str]],
                                     output_dir: str,
                                     fps: int = 4,
                                     window_size: int = 5):
    """Generate animated learning curves to visualize progress over time."""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # Define metrics to animate
    metric_configs = {
        'win_rates': {
            'title': 'Win Rate vs Random Agent',
            'ylabel': 'Win Rate',
            'ylim': (0, 1),
            'smooth': True
        },
        'exploitability': {
            'title': 'Exploitability',
            'ylabel': 'Exploitability',
            'yscale': 'log',
            'smooth': True
        }
    }
    
    for metric_name, config in metric_configs.items():
        if metric_name not in metrics or not metrics[metric_name]:
            continue
            
        values = metrics[metric_name]
        total_frames = len(values)
        
        if total_frames < 5:
            print(f"Not enough data points for animation: {metric_name}")
            continue
        
        # For efficiency, only generate 10 frames for the animation regardless of data size
        step_size = max(1, total_frames // 10)
        frame_indices = list(range(5, total_frames + 1, step_size))
        if frame_indices[-1] != total_frames:
            frame_indices.append(total_frames)  # Always include the last frame
        
        print(f"Generating animation for {metric_name} with {len(frame_indices)} frames")
            
        # Determine y-axis limits based on the range of values
        if 'ylim' not in config:
            min_val = min(values)
            max_val = max(values)
            margin = (max_val - min_val) * 0.1
            # For log scale, ensure the minimum is always positive
            if config.get('yscale') == 'log':
                min_val = max(0.001, min_val)
            config['ylim'] = (max(0.001, min_val - margin), max_val + margin)
            
        # Generate plots at key frames
        fig, ax = plt.subplots(figsize=(10, 6))
        line_raw, = ax.plot([], [], 'o-', alpha=0.4, label='Raw Values')
        line_smooth, = ax.plot([], [], '-', linewidth=2, label='Smoothed')
        milestone_lines = []
        
        # Configure plot
        ax.set_xlabel('Iteration')
        ax.set_ylabel(config['ylabel'])
        ax.set_xlim(0, total_frames)
        ax.set_ylim(config['ylim'])
        if 'yscale' in config:
            ax.set_yscale(config['yscale'])
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Add milestone markers (all at once since they're static)
        if milestones:
            for iteration, description in milestones.items():
                if 0 <= iteration < total_frames:
                    line = ax.axvline(x=iteration, color='r', linestyle='--', alpha=0.5)
                    text = ax.text(iteration, config['ylim'][0] + 0.02 * (config['ylim'][1] - config['ylim'][0]),
                           f"  {description}", rotation=90, verticalalignment='bottom')
                    milestone_lines.append((line, text))
        
        # Progress and performance text elements
        progress_text = ax.text(0.5, 0.01, "", transform=fig.transFigure, 
                               fontsize=10, horizontalalignment='center', color='blue')
        perf_text = ax.text(0.5, 0.04, "", transform=fig.transFigure,
                           fontsize=10, horizontalalignment='center', color='green')
        
        # Generate frames for animation
        frames = []
        for frame_idx in frame_indices:
            # Get data up to this frame
            current_values = values[:frame_idx]
            x = list(range(len(current_values)))
            
            # Update raw data line
            line_raw.set_data(x, current_values)
            
            # Update smoothed line if applicable
            if config.get('smooth', False) and len(current_values) > window_size:
                smoothed = smooth_curve(current_values, window_size)
                line_smooth.set_data(x, smoothed)
            else:
                line_smooth.set_data([], [])  # Hide line
            
            # Update title
            ax.set_title(f"{config['title']} (Iteration {frame_idx} / {total_frames})")
            
            # Update progress text
            progress_text.set_text(f"Training progress: {frame_idx/total_frames:.1%}")
            
            # Update performance text
            current_value = current_values[-1]
            perf_txt = f"Current: {current_value:.4f}   "
            if len(current_values) > 5:
                if metric_name == 'exploitability':
                    improvement = current_values[-5] / (current_value + 1e-8)
                    perf_txt += f"Improvement: {improvement:.2f}x (lower is better)"
                else:
                    improvement = (current_value / (current_values[-5] + 1e-8)) - 1
                    perf_txt += f"Improvement: {improvement*100:.2f}% (higher is better)"
            perf_text.set_text(perf_txt)
            
            # Draw and capture the frame
            fig.canvas.draw()
            image = np.array(fig.canvas.renderer.buffer_rgba())
            frames.append(image)
        
        # Close the figure
        plt.close(fig)
        
        # Save the animation directly as a GIF
        output_path = os.path.join(output_dir, f"{metric_name}_animated.gif")
        imageio.mimsave(output_path, frames, fps=fps, loop=0)
        print(f"Saved animation to {output_path}")

def create_learning_summary(metrics: Dict[str, List[float]], 
                          milestones: Optional[Dict[int, str]], 
                          output_dir: str):
    """Create a text summary of learning progress with milestone annotations."""
    
    if not metrics:
        return
    
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, 'learning_summary.md')
    
    with open(output_path, 'w') as f:
        f.write("# Poker AI Learning Summary\n\n")
        f.write(f"*Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n\n")
        
        # Overall statistics
        f.write("## Training Statistics\n\n")
        
        if 'win_rates' in metrics and metrics['win_rates']:
            win_rates = metrics['win_rates']
            f.write(f"- **Final win rate**: {win_rates[-1]:.4f}\n")
            f.write(f"- **Best win rate**: {max(win_rates):.4f} (iteration {win_rates.index(max(win_rates))})\n")
            f.write(f"- **Initial win rate**: {win_rates[0]:.4f}\n")
            f.write(f"- **Improvement**: {(win_rates[-1]/max(win_rates[0], 1e-6) - 1)*100:.2f}%\n\n")
        
        if 'exploitability' in metrics and metrics['exploitability']:
            exploit = metrics['exploitability']
            f.write(f"- **Final exploitability**: {exploit[-1]:.6f}\n")
            f.write(f"- **Best exploitability**: {min(exploit):.6f} (iteration {exploit.index(min(exploit))})\n")
            f.write(f"- **Initial exploitability**: {exploit[0]:.6f}\n\n")
        
        if 'training_time' in metrics and metrics['training_time']:
            times = metrics['training_time']
            total_time = sum(times)
            f.write(f"- **Total training time**: {total_time:.2f} seconds ({total_time/3600:.2f} hours)\n")
            f.write(f"- **Average iteration time**: {np.mean(times):.2f} seconds\n\n")
        
        if 'policy_size' in metrics and metrics['policy_size']:
            f.write(f"- **Final strategy pool size**: {metrics['policy_size'][-1]}\n\n")
        
        # Milestone summary
        if milestones:
            f.write("## Training Milestones\n\n")
            
            win_rates = metrics.get('win_rates', [])
            exploitability = metrics.get('exploitability', [])
            
            for iteration, description in sorted(milestones.items()):
                f.write(f"### Iteration {iteration}: {description}\n\n")
                
                # Add win rate and exploitability at milestone if available
                if win_rates and 0 <= iteration < len(win_rates):
                    f.write(f"- Win rate: {win_rates[iteration]:.4f}\n")
                if exploitability and 0 <= iteration < len(exploitability):
                    f.write(f"- Exploitability: {exploitability[iteration]:.6f}\n")
                f.write("\n")
        
        # Learning rate analysis
        if 'win_rates' in metrics and len(metrics['win_rates']) > 10:
            f.write("## Learning Rate Analysis\n\n")
            
            win_rates = metrics['win_rates']
            quarter = len(win_rates) // 4
            
            if quarter > 0:
                first_quarter = win_rates[quarter] - win_rates[0]
                second_quarter = win_rates[2*quarter] - win_rates[quarter]
                third_quarter = win_rates[3*quarter] - win_rates[2*quarter]
                fourth_quarter = win_rates[-1] - win_rates[3*quarter]
                
                f.write("### Win Rate Improvement by Quarter\n\n")
                f.write(f"1. First quarter: {first_quarter:.4f}\n")
                f.write(f"2. Second quarter: {second_quarter:.4f}\n")
                f.write(f"3. Third quarter: {third_quarter:.4f}\n")
                f.write(f"4. Fourth quarter: {fourth_quarter:.4f}\n\n")
                
                # Identify learning plateaus
                improvements = [first_quarter, second_quarter, third_quarter, fourth_quarter]
                quarters = ["first", "second", "third", "fourth"]
                
                # Check for plateaus
                plateaus = [quarters[i] for i in range(len(improvements)) if improvements[i] < 0.01]
                if plateaus:
                    f.write(f"**Learning plateaus detected** in the {', '.join(plateaus)} quarter(s).\n\n")
                else:
                    f.write("**No significant learning plateaus detected**.\n\n")
    
    print(f"Saved learning summary to {output_path}")
    
def main():
    args = parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Load metrics data
    metrics = load_metrics(args.metrics_file)
    if not metrics:
        print("No metrics data found. Exiting.")
        return
    
    # Load milestone data
    milestones = load_milestones(args.milestones)
    
    # Load comparison data if provided
    comparison_metrics = None
    if args.comparison:
        comparison_metrics = load_metrics(args.comparison)
    
    # Generate static plots
    generate_static_plots(metrics, milestones, args.output_dir, comparison_metrics, args.window_size)
    
    # Generate animations if requested
    if args.animate:
        generate_animated_learning_curves(metrics, milestones, args.output_dir, args.gif_fps, args.window_size)
    
    # Create learning summary
    create_learning_summary(metrics, milestones, args.output_dir)
    
    print(f"Analysis complete. Results available in {args.output_dir}")

if __name__ == "__main__":
    main()