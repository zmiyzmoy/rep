# Poker AI with PSRO

A reinforcement learning system for training poker AI using Policy Space Response Oracles (PSRO) with PyTorch and OpenSpiel. This AI model can learn No-Limit Texas Hold'em strategies through self-play.

## Features

- **PSRO Algorithm Implementation**: Policy Space Response Oracles for discovering effective poker strategies
- **Neural Network Architecture**: Deep neural networks for strategy and regret modeling
- **Cloud Optimized**: Scripts for training on Google Cloud A100 GPUs with spot instance support
- **Checkpointing**: Built-in checkpointing for graceful recovery from spot instance preemption
- **JSON Interface**: Interface for using the trained model via JSON input/output
- **Enhanced Opponent Modeling**: Track opponent tendencies like VPIP, PFR, and street-specific aggression
- **Advanced Analytics**: 
  - Comprehensive metrics tracking and visualization tools
  - Animated learning curves with milestone markers
  - Position-based win rate analysis
  - Learning plateau detection

## Requirements

- Python 3.7+
- PyTorch 1.8+
- OpenSpiel
- Ray (for distributed computing)
- NumPy, SciPy, Matplotlib, etc.

## Getting Started

### Installation

1. Install dependencies:

```bash
pip install torch numpy ray open-spiel joblib scikit-learn matplotlib tqdm
```

2. Clone the repository:

```bash
git clone <repository-url>
cd poker-ai
```

### Basic Usage

1. Initialize the model:

```bash
python init_model.py
```

2. Run self-play training:

```bash
python poker_rl.py --mode selfplay --num_episodes 5 --verbose
```

3. Run a full training session:

```bash
python cloud_trainer.py --mode train --num_episodes 1000 --verbose
```

### Advanced Usage

#### Training on Google Cloud A100 GPUs

1. Update configuration in `create_gcp_spot_instance.sh` with your GCP project, zone, and bucket details.

2. Run the script to create a spot VM with A100 GPU:

```bash
chmod +x create_gcp_spot_instance.sh
./create_gcp_spot_instance.sh
```

3. The VM will automatically start training using the startup script.

#### Inference with JSON Input

1. Create a JSON file with poker hand scenarios (see `sample_hand.json` for format).

2. Run inference:

```bash
python poker_json_inference.py --input sample_hand.json --output results.json
```

3. View the recommendations in `results.json`.

#### Analyzing Training Results

```bash
python analyze_training.py --metrics_file ./poker/logs/metrics.json --output_dir ./analysis
```

This will generate charts and an HTML report of the training progress.

## Project Structure

- `poker_rl.py`: Main script for running training and evaluation
- `models.py`: Neural network model definitions
- `environment.py`: Poker environment wrapper for OpenSpiel
- `psro.py`: Implementation of the PSRO algorithm
- `cloud_trainer.py`: Optimized training script for cloud GPUs
- `cloud_spot_runner.py`: Script for managing training on preemptible instances
- `poker_json_inference.py`: Script for performing inference with JSON input/output
- `analyze_training.py`: Script for analyzing and visualizing training results

## Training for 100K+ Hands

For training on a large number of hands (100K+), use the cloud trainer script:

```bash
python cloud_trainer.py --mode train --num_episodes 100000 --checkpoint_dir ./poker/checkpoints --save_interval 5
```

This will save checkpoints every 5 iterations, and can be resumed if interrupted.

## License

[MIT License](LICENSE)

## Acknowledgments

- OpenSpiel library by DeepMind for poker game implementation
- Policy Space Response Oracles (PSRO) algorithm by Lanctot et al.