#!/usr/bin/env python3
import os
import json
import logging
import argparse
import numpy as np
import torch
import pyspiel
from typing import List, Dict, Any, Tuple, Optional

# Import project modules
from models import Config, RegretNet, StrategyNet, StateProcessor
from environment import TorchPolicy
from psro import PSROSolver

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('poker_inference.log'),
        logging.StreamHandler()
    ]
)

def parse_args():
    parser = argparse.ArgumentParser(description="Poker AI JSON Inference")
    parser.add_argument('--input', type=str, required=True, help='Input JSON file')
    parser.add_argument('--output', type=str, default='inference_results.json', help='Output JSON file')
    parser.add_argument('--model_dir', type=str, default='./poker/models', help='Model directory')
    parser.add_argument('--checkpoint', type=str, default='final', help='Checkpoint to use (final, best, or path)')
    parser.add_argument('--game_config', type=str, default='6max_nlh',
                        choices=['6max_nlh', '9max_nlh', 'hu_nlh'], help='Game configuration')
    parser.add_argument('--stack_size', type=int, default=100, help='Stack size in big blinds')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    return parser.parse_args()

def init_config(args):
    """Initialize configuration."""
    config = Config()
    config.MODEL_PATH = os.path.join(args.model_dir, 'psro_model.pt')
    config.BEST_MODEL_PATH = os.path.join(args.model_dir, 'psro_best.pt')
    config.KMEANS_PATH = os.path.join(args.model_dir, 'kmeans.joblib')
    
    # Configure game
    if args.game_config == '6max_nlh':
        config.NUM_PLAYERS = 6
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack={args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size} {args.stack_size},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    elif args.game_config == '9max_nlh':
        config.NUM_PLAYERS = 9
        stacks = f"{args.stack_size} " * 9
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=9,numRounds=4,blind=0.5 1 1 1 1 1 1 1 1,raiseSize=0.10 0.20 0.40 0.80,stack={stacks.strip()},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    elif args.game_config == 'hu_nlh':
        config.NUM_PLAYERS = 2
        config.GAME_NAME = f"universal_poker(betting=nolimit,numPlayers=2,numRounds=4,blind=1 2,raiseSize=0.10 0.20 0.40 0.80,stack={args.stack_size} {args.stack_size},numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"
    
    return config

def load_json_input(input_file):
    """Load and validate the JSON input file."""
    try:
        with open(input_file, 'r') as f:
            data = json.load(f)
        
        # Basic validation
        if not isinstance(data, list):
            data = [data]  # Convert single scenario to list
        
        for i, scenario in enumerate(data):
            if not isinstance(scenario, dict):
                raise ValueError(f"Scenario {i} is not a dictionary")
            
            # Validate hole cards
            if 'hole_cards' not in scenario:
                raise ValueError(f"Scenario {i} is missing hole_cards")
            
            # Board cards are optional
            if 'board' in scenario and not isinstance(scenario['board'], list):
                raise ValueError(f"Scenario {i} has invalid board format")
        
        return data
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON format: {e}")
    except Exception as e:
        raise ValueError(f"Error loading input file: {e}")

def card_string_to_id(card_str):
    """Convert a card string like 'Ah' to its internal representation."""
    ranks = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, 
             '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
    suits = {'c': 0, 'd': 1, 'h': 2, 's': 3}
    
    if len(card_str) != 2:
        raise ValueError(f"Invalid card format: {card_str}")
    
    rank_char = card_str[0].upper()
    suit_char = card_str[1].lower()
    
    if rank_char not in ranks:
        raise ValueError(f"Invalid rank: {rank_char}")
    if suit_char not in suits:
        raise ValueError(f"Invalid suit: {suit_char}")
    
    # In OpenSpiel, cards are encoded as rank + (suit * 13)
    return ranks[rank_char] + (suits[suit_char] * 13)

def reconstruct_game_state(game, scenario):
    """
    Reconstruct a game state from a scenario description.
    This is a complex function as we need to create the state that matches the scenario.
    """
    # Create initial state
    state = game.new_initial_state()
    
    # Extract scenario information
    hole_cards = scenario.get('hole_cards', [])
    board = scenario.get('board', [])
    betting_history = scenario.get('betting_history', [])
    hero_position = scenario.get('hero_position', 0)
    
    # For now, this is a simplified implementation that focuses on the hero's decision point
    # In a full implementation, you would need to track the full game state
    
    # This is a placeholder for the reconstruction logic
    # In a real implementation, you would:
    # 1. Apply chance outcomes to deal specific cards
    # 2. Apply betting actions to reach the current decision point
    
    # For now, we'll return a basic state
    return state

def process_scenarios(scenarios, solver, state_processor, config):
    """Process poker hand scenarios and generate recommendations."""
    results = []
    
    # Load game
    game = pyspiel.load_game(config.GAME_NAME)
    
    # Create policy from solver's model
    policy = TorchPolicy(game, solver.regret_net, state_processor)
    
    for scenario in scenarios:
        try:
            # Convert card strings to internal IDs
            if 'hole_cards' in scenario:
                hole_cards_ids = [card_string_to_id(card) for card in scenario['hole_cards']]
                scenario['hole_cards_ids'] = hole_cards_ids
            
            if 'board' in scenario:
                board_ids = [card_string_to_id(card) for card in scenario['board']]
                scenario['board_ids'] = board_ids
            
            # Reconstruct game state
            state = reconstruct_game_state(game, scenario)
            
            # Get legal actions
            legal_actions = state.legal_actions()
            
            # Use policy to get action probabilities
            action_probs = policy.action_probabilities(state)
            
            # Calculate expected values for actions
            evs = calculate_action_evs(solver, state, state_processor)
            
            # Format recommendations
            recommendations = format_recommendations(action_probs, evs)
            
            # Create result
            result = {
                'scenario': scenario,
                'recommendations': recommendations,
                'best_action': get_best_action(recommendations),
                'legal_actions': legal_actions
            }
            
            results.append(result)
            
        except Exception as e:
            logging.error(f"Error processing scenario: {e}")
            results.append({
                'scenario': scenario,
                'error': str(e)
            })
    
    return results

def calculate_action_evs(solver, state, state_processor):
    """Calculate expected values for each action."""
    player = state.current_player()
    legal_actions = state.legal_actions()
    
    # Process state for neural network
    processed_state = state_processor.process([state], [player])
    state_tensor = torch.tensor(processed_state, dtype=torch.float32, device=solver.device)
    
    # Get action values from regret network
    with torch.no_grad():
        action_values = solver.regret_net(state_tensor)[0].cpu().numpy()
    
    # Create action to EV mapping
    action_evs = {}
    for action in legal_actions:
        action_evs[action] = float(action_values[action])
    
    return action_evs

def format_recommendations(action_probs, action_evs):
    """Format action recommendations in human-readable form."""
    recommendations = []
    
    # Action type mapping
    action_types = {
        0: "fold",
        1: "call/check",
        2: "raise_half_pot",
        3: "raise_pot",
        4: "raise_2x_pot",
        5: "all_in"
    }
    
    for action, prob in action_probs.items():
        action_type = action_types.get(action, f"action_{action}")
        ev = action_evs.get(action, 0.0)
        
        recommendations.append({
            'action': action,
            'action_type': action_type,
            'probability': float(prob),
            'ev': float(ev)
        })
    
    # Sort by expected value (descending)
    recommendations.sort(key=lambda x: x['ev'], reverse=True)
    
    return recommendations

def get_best_action(recommendations):
    """Get the best action based on recommendations."""
    if not recommendations:
        return None
    
    # Get the action with highest EV
    return recommendations[0]['action_type']

def format_and_save_results(results, output_file):
    """Format and save results to a JSON file."""
    # Clean output for JSON serialization
    clean_results = []
    for result in results:
        clean_result = {}
        for key, value in result.items():
            if key == 'scenario':
                clean_result[key] = value
            elif key == 'recommendations':
                clean_result[key] = value
            elif key == 'best_action':
                clean_result[key] = value
            elif key == 'legal_actions':
                clean_result[key] = [int(a) for a in value]
            elif key == 'error':
                clean_result[key] = value
        clean_results.append(clean_result)
    
    # Save to file
    with open(output_file, 'w') as f:
        json.dump(clean_results, f, indent=2)

def main():
    args = parse_args()
    
    # Initialize configuration
    config = init_config(args)
    
    # Initialize state processor
    state_processor = StateProcessor(config)
    
    # Initialize solver
    solver = PSROSolver(config, state_processor)
    
    # Load checkpoint
    if args.checkpoint == 'best':
        solver.load_checkpoints("best")
    else:
        solver.load_checkpoints("final")
    
    # Load scenarios from JSON
    scenarios = load_json_input(args.input)
    logging.info(f"Loaded {len(scenarios)} scenarios from {args.input}")
    
    # Process scenarios
    results = process_scenarios(scenarios, solver, state_processor, config)
    
    # Save results
    format_and_save_results(results, args.output)
    logging.info(f"Saved results to {args.output}")

if __name__ == "__main__":
    main()