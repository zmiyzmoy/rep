import numpy as np
from collections import deque
from typing import List, Tuple, Dict, Any
import logging
from config import Config

config = Config()

class RewardNormalizer:
    def __init__(self, eps: float = 1e-8, max_size: int = 10000):
        self.rewards = deque(maxlen=max_size)
        self.eps = eps
        self.mean = 0.0
        self.std = 1.0
        logging.info("RewardNormalizer инициализирован")

    def update(self, reward: float):
        self.rewards.append(reward)
        self.mean = np.mean(self.rewards) if self.rewards else 0.0
        self.std = np.std(self.rewards) + self.eps if self.rewards else 1.0

    def normalize(self, reward: float) -> float:
        if config.REWARD_NORMALIZATION == 'stack':
            return reward / 100.0  # Normalize by stack size
        else:
            return (reward - self.mean) / self.std if self.rewards else reward

class PrioritizedReplayBuffer:
    def __init__(self, capacity: int = config.BUFFER_CAPACITY, alpha: float = config.PRIORITY_ALPHA):
        self.buffer = deque(maxlen=capacity)
        self.alpha = alpha
        self.priorities = deque(maxlen=capacity)
        self._max_priority = 1.0
        logging.info(f"PrioritizedReplayBuffer initialized with capacity={capacity}, alpha={alpha}")

    def add_batch(self, experiences):
        self.buffer.extend(experiences)
        self.priorities.extend([self._max_priority] * len(experiences))
        logging.debug(f"Added {len(experiences)} experiences to buffer, total size: {len(self.buffer)}")

    def sample(self, batch_size: int, beta: float = config.PRIORITY_BETA_START):
        if len(self.buffer) == 0:
            return [], [], np.array([])
        
        probs = np.array(self.priorities) ** self.alpha
        probs_sum = probs.sum()
        if probs_sum <= 0:
            probs = np.ones(len(self.buffer)) / len(self.buffer)
        else:
            probs /= probs_sum
            
        indices = np.random.choice(len(self.buffer), size=min(batch_size, len(self.buffer)), p=probs, replace=False)
        samples = [self.buffer[i] for i in indices]
        
        # Calculate importance sampling weights
        weights = (len(self.buffer) * probs[indices]) ** (-beta)
        weights /= weights.max()
        
        return samples, indices, weights.astype(np.float32)

    def update_priorities(self, indices, priorities):
        for idx, priority in zip(indices, priorities):
            if idx < len(self.priorities):  # Safety check
                self.priorities[idx] = priority
                self._max_priority = max(self._max_priority, priority)

    def __len__(self):
        return len(self.buffer)

class Transition:
    def __init__(self, state, action, reward, next_state, done, legal_actions=None, info=None):
        self.state = state
        self.action = action
        self.reward = reward
        self.next_state = next_state
        self.done = done
        self.legal_actions = legal_actions
        self.info = info if info is not None else {}
