import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.amp import autocast
from torch.cuda.amp import GradScaler
import numpy as np
import logging
import joblib
from sklearn.cluster import KMeans
from collections import deque
from typing import List, Tuple, Dict, Optional

# Device configuration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Configuration class
class Config:
    def __init__(self):
        self.BASE_DIR = './poker'
        self.MODEL_PATH = os.path.join(self.BASE_DIR, 'models', 'psro_model.pt')
        self.BEST_MODEL_PATH = os.path.join(self.BASE_DIR, 'models', 'psro_best.pt')
        self.LOG_DIR = os.path.join(self.BASE_DIR, 'logs')
        self.KMEANS_PATH = os.path.join(self.BASE_DIR, 'models', 'kmeans.joblib')
        self.NUM_EPISODES = 10
        self.BATCH_SIZE = 64
        self.GAMMA = 0.96
        self.BUFFER_CAPACITY = 10000
        self.NUM_WORKERS = 8
        self.STEPS_PER_WORKER = 500
        self.SELFPLAY_UPDATE_FREQ = 50
        self.LOG_FREQ = 10
        self.TEST_INTERVAL = 50
        self.LEARNING_RATE = 1e-4
        self.NUM_PLAYERS = 6
        self.GRAD_CLIP_VALUE = 5.0
        self.CHECKPOINT_INTERVAL = 300
        self.NUM_BUCKETS = 50
        self.BB = 2
        self.MAX_STRATEGY_POOL = 10
        self.MAX_DICT_SIZE = 10000
        self.REWARD_NORMALIZATION = 'stack'
        self.GAME_NAME = "universal_poker(betting=nolimit,numPlayers=6,numRounds=4,blind=1 2 3 4 5 6,raiseSize=0.10 0.20 0.40 0.80,stack=100 100 100 100 100 100,numSuits=4,numRanks=13,numHoleCards=2,numBoardCards=0 3 1 1)"

# Reward normalization
class RewardNormalizer:
    def __init__(self, eps: float = 1e-8, max_size: int = 10000):
        self.rewards = deque(maxlen=max_size)
        self.eps = eps
        self.mean = 0.0
        self.std = 1.0
        logging.info("RewardNormalizer initialized")

    def update(self, reward: float):
        try:
            self.rewards.append(reward)
            self.mean = np.mean(self.rewards) if self.rewards else 0.0
            self.std = np.std(self.rewards) + self.eps if self.rewards else 1.0
        except Exception as e:
            logging.error(f"Error in update RewardNormalizer: {e}")
            # Continue safely by maintaining previous values

    def normalize(self, reward: float) -> float:
        if not self.rewards:
            logging.debug("Reward buffer empty, returning default normalized value 0")
            return 0.0
        try:
            return (reward - self.mean) / self.std
        except Exception as e:
            logging.error(f"Error in normalize RewardNormalizer: {e}")
            return reward  # Fall back to original reward if normalization fails

# Prioritized experience replay buffer
class PrioritizedReplayBuffer:
    def __init__(self, capacity: int, alpha: float = 0.6):
        self.buffer = deque(maxlen=capacity)
        self._lock = torch.multiprocessing.Lock() if hasattr(torch, 'multiprocessing') else None
        self.alpha = alpha
        self.priorities = deque(maxlen=capacity)
        self._max_priority = 1.0
        self.global_step = 0
        logging.info("PrioritizedReplayBuffer initialized")

    def add_batch(self, experiences, processor=None):
        try:
            # Use lock if multiprocessing is enabled
            if self._lock:
                self._lock.acquire()
            
            # Process state if processor is provided
            if processor:
                processed_experiences = []
                states, actions, rewards, next_states, dones, player_ids, bets, stacks, stages = zip(*experiences)
                processed_states = processor.process(states, player_ids, bets, stacks, stages)
                processed_next_states = processor.process(next_states, player_ids, bets, stacks, stages)
                for i in range(len(experiences)):
                    processed_experiences.append((
                        processed_states[i], actions[i], rewards[i], processed_next_states[i], dones[i],
                        player_ids[i], bets[i], stacks[i], stages[i]
                    ))
                self.buffer.extend(processed_experiences)
            else:
                self.buffer.extend(experiences)
                
            self.priorities.extend([self._max_priority] * len(experiences))
            logging.debug(f"Added {len(experiences)} experiences to buffer, total size: {len(self.buffer)}")
        except Exception as e:
            logging.error(f"Error in add_batch: {e}")
            raise
        finally:
            if self._lock and self._lock.locked():
                self._lock.release()

    def sample(self, batch_size: int, beta: float = 0.4):
        if self._lock:
            self._lock.acquire()
        try:
            if len(self.buffer) == 0:
                return [], [], np.array([])
                
            probs = np.array(self.priorities) ** self.alpha
            probs_sum = probs.sum()
            if probs_sum <= 0:
                probs = np.ones(len(self.buffer)) / len(self.buffer)
            else:
                probs /= probs_sum
                
            indices = np.random.choice(len(self.buffer), size=min(batch_size, len(self.buffer)), p=probs, replace=False)
            samples = [self.buffer[i] for i in indices]
            weights = (len(self.buffer) * probs[indices]) ** (-beta)
            weights /= weights.max()
            
            # Log buffer stats
            if hasattr(self, 'global_step') and self.global_step % 100 == 0:
                logging.debug(f"Buffer size: {len(self.buffer)}, max priority: {self._max_priority}")
                
            return samples, indices, weights.astype(np.float32)
        except Exception as e:
            logging.error(f"Error in sample: {e}")
            return [], [], np.array([])
        finally:
            if self._lock and self._lock.locked():
                self._lock.release()

    def update_priorities(self, indices, priorities):
        if self._lock:
            self._lock.acquire()
        try:
            for idx, priority in zip(indices, priorities):
                if idx < len(self.priorities):
                    self.priorities[idx] = float(priority)
                    self._max_priority = max(self._max_priority, float(priority))
        except Exception as e:
            logging.error(f"Error in update_priorities: {e}")
        finally:
            if self._lock and self._lock.locked():
                self._lock.release()

    def __len__(self):
        return len(self.buffer)
        
    def set_global_step(self, step: int):
        self.global_step = step

# Neural network for regret estimation
class RegretNet(nn.Module):
    def __init__(self, input_size: int, num_actions: int):
        super().__init__()
        assert input_size > 0, f"Invalid input_size: {input_size}"
        self.net = nn.Sequential(
            nn.Linear(input_size, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_actions)
        )
        for layer in self.net:
            if isinstance(layer, nn.Linear):
                nn.init.kaiming_normal_(layer.weight, mode='fan_in', nonlinearity='relu')
        logging.info("RegretNet initialized")

    def forward(self, x):
        # Disable autocast to prevent BFloat16 issues
        return self.net(x.to(dtype=torch.float32))

# Neural network for strategy prediction
class StrategyNet(nn.Module):
    def __init__(self, input_size: int, num_actions: int):
        super().__init__()
        assert input_size > 0, f"Invalid input_size: {input_size}"
        self.net = nn.Sequential(
            nn.Linear(input_size, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, num_actions)
        )
        for layer in self.net:
            if isinstance(layer, nn.Linear):
                nn.init.kaiming_normal_(layer.weight, mode='fan_in', nonlinearity='relu')
        logging.info("StrategyNet initialized")

    def forward(self, x):
        # Disable autocast to prevent BFloat16 issues
        return self.net(x.to(dtype=torch.float32))

# Card embedding module
class CardEmbedding(nn.Module):
    def __init__(self):
        super().__init__()
        self.rank_embed = nn.Embedding(13, 8).to(device)
        self.suit_embed = nn.Embedding(4, 4).to(device)
        self.rank_embed.weight.data = self.rank_embed.weight.data.to(dtype=torch.float32)
        self.suit_embed.weight.data = self.suit_embed.weight.data.to(dtype=torch.float32)
        logging.info("CardEmbedding initialized")

    def forward(self, cards: List[int]) -> torch.Tensor:
        ranks = torch.tensor([c % 13 for c in cards], dtype=torch.long, device=device)
        suits = torch.tensor([c // 13 for c in cards], dtype=torch.long, device=device)
        rank_emb = self.rank_embed(ranks).mean(dim=0).to(dtype=torch.float32)
        suit_emb = self.suit_embed(suits).mean(dim=0).to(dtype=torch.float32)
        return torch.cat([rank_emb, suit_emb]).to(dtype=torch.float32)

# State processing class
class StateProcessor:
    def __init__(self, config):
        self.config = config
        self.card_embedding = CardEmbedding()
        self.buckets = self._load_or_precompute_buckets()
        self.state_size = config.NUM_BUCKETS + config.NUM_PLAYERS * 3 + 4 + 5
        self.cache = {}
        self.max_cache_size = 1000
        logging.info(f"StateProcessor initialized, state_size={self.state_size}")

    def _load_or_precompute_buckets(self):
        if os.path.exists(self.config.KMEANS_PATH):
            buckets = joblib.load(self.config.KMEANS_PATH)
            logging.info(f"Loaded buckets from {self.config.KMEANS_PATH}")
            return buckets
        all_hands = []
        for r1 in range(13):
            for r2 in range(r1, 13):
                for suited in [0, 1]:
                    hand = [r1 + suited * 13, r2 + suited * 13]
                    embedding = self.card_embedding(hand).cpu().detach().numpy().astype(np.float32)
                    all_hands.append(embedding)
        kmeans = KMeans(n_clusters=self.config.NUM_BUCKETS, random_state=42).fit(np.array(all_hands, dtype=np.float32))
        joblib.dump(kmeans, self.config.KMEANS_PATH)
        logging.info(f"Buckets computed and saved to {self.config.KMEANS_PATH}")
        return kmeans

    def process(self, states: List, player_ids: List[int], bets: List[List[float]] = None, 
                stacks: List[List[float]] = None, stages: List[List[int]] = None, 
                opponent_stats: Optional['OpponentStats'] = None) -> np.ndarray:
        batch_size = len(states)
        if bets is None:
            bets = [[0] * self.config.NUM_PLAYERS] * batch_size
        if stacks is None:
            stacks = [[100] * self.config.NUM_PLAYERS] * batch_size
        if stages is None:
            stages = [[0, 0, 0, 0]] * batch_size

        state_keys = [f"{s.information_state_string(pid)}_{pid}_{tuple(b)}_{tuple(stk)}" 
                     for s, pid, b, stk in zip(states, player_ids, bets, stacks)]
        cached = [self.cache.get(key) for key in state_keys]
        if all(c is not None for c in cached):
            return np.array(cached, dtype=np.float32)

        info_states = [s.information_state_tensor(pid) for s, pid in zip(states, player_ids)]
        cards_batch = []
        for info in info_states:
            private_cards = [int(i) for i, c in enumerate(info[:52]) if c > 0][:2]
            if not private_cards:
                private_cards = [0, 1]
            elif len(private_cards) < 2:
                private_cards.extend([1] * (2 - len(private_cards)))
            cards_batch.append(private_cards)

        card_embs = torch.stack([self.card_embedding(cards) for cards in cards_batch]).cpu().detach().numpy().astype(np.float32)
        bucket_idxs = self.buckets.predict(card_embs)
        bucket_one_hot = np.zeros((batch_size, self.config.NUM_BUCKETS), dtype=np.float32)
        bucket_one_hot[np.arange(batch_size), bucket_idxs] = 1.0

        bets_norm = np.array(bets, dtype=np.float32) / (np.array(stacks, dtype=np.float32) + 1e-8)
        stacks_norm = np.array(stacks, dtype=np.float32) / 1000.0
        pots = np.array([sum(b) for b in bets], dtype=np.float32)
        sprs = np.array([stk[pid] / pot if pot > 0 else 10.0 for stk, pid, pot in zip(stacks, player_ids, pots)], dtype=np.float32)
        positions = np.array([(pid - s.current_player()) % self.config.NUM_PLAYERS / self.config.NUM_PLAYERS 
                             for s, pid in zip(states, player_ids)], dtype=np.float32)
        action_history = np.array([([0] * self.config.NUM_PLAYERS if not hasattr(s, 'action_history') else 
                                  [min(h, 4) for h in s.action_history()[-self.config.NUM_PLAYERS:]]) 
                                  for s in states], dtype=np.float32)

        processed = np.concatenate([
            bucket_one_hot, bets_norm, stacks_norm, action_history, np.array(stages, dtype=np.float32),
            np.array([sprs, positions, np.zeros(batch_size), np.zeros(batch_size), np.zeros(batch_size)], dtype=np.float32).T
        ], axis=1).astype(np.float32)

        if np.any(np.isnan(processed)) or np.any(np.isinf(processed)):
            logging.error(f"NaN/Inf in processed: {processed}")
            raise ValueError("Invalid state processing detected")

        if len(self.cache) >= self.max_cache_size:
            self.cache.clear()
        for key, proc in zip(state_keys, processed):
            self.cache[key] = proc
        return processed

# Opponent statistics tracking
class OpponentStats:
    def __init__(self):
        self.stats = {i: {
            'vpip': 0, 'pfr': 0, 'af': 0, 'hands': 0, 'folds': 0, 'calls': 0, 'raises': 0, 'last_bet': 0,
            'fold_to_cbet': 0, 'cbet_opp': 0, 'fold_to_3bet': 0, '3bet_opp': 0, 'check_raise': 0, 'check_opp': 0,
            'pos_winrate': {pos: {'wins': 0, 'hands': 0} for pos in range(6)},
            'call_vs_raise_freq': 0, 'raise_opp': 0, 'street_aggression': [0] * 4
        } for i in range(6)}
        self.histories = []
        logging.info("OpponentStats initialized")

    def update(self, player_id: int, action_type: str, round_idx: int = 0, is_aggressor: bool = False, 
               amount: float = 0, pot: float = 0, position: int = 0, is_cbet: bool = False, 
               is_3bet: bool = False, is_check: bool = False, won: float = 0, is_raise: bool = False):
        if player_id not in self.stats:
            return
        
        player = self.stats[player_id]
        player['hands'] += 1
        player['pos_winrate'][position]['hands'] += 1
        
        if won > 0:
            player['pos_winrate'][position]['wins'] += 1
        
        # Update action counts
        if action_type == 'fold':
            player['folds'] += 1
            if is_cbet:
                player['fold_to_cbet'] += 1
            if is_3bet:
                player['fold_to_3bet'] += 1
        elif action_type == 'call' or action_type == 'check':
            player['calls'] += 1
            player['vpip'] = (player['calls'] + player['raises']) / max(1, player['hands'])
            if is_raise:
                player['call_vs_raise_freq'] += 1
        elif action_type == 'raise' or action_type == 'bet':
            player['raises'] += 1
            player['pfr'] = player['raises'] / max(1, player['hands'])
            player['vpip'] = (player['calls'] + player['raises']) / max(1, player['hands'])
            player['last_bet'] = amount
            player['street_aggression'][round_idx] += 1
            if is_check:
                player['check_raise'] += 1
        
        # Track opportunities
        if is_cbet:
            player['cbet_opp'] += 1
        if is_3bet:
            player['3bet_opp'] += 1
        if is_check:
            player['check_opp'] += 1
        if is_raise:
            player['raise_opp'] += 1
            
        # Aggression factor
        if player['calls'] > 0:
            player['af'] = player['raises'] / max(1, player['calls'])
        
    def get_metrics(self, player_id: int) -> Dict[str, float]:
        if player_id not in self.stats:
            return {}
            
        player = self.stats[player_id]
        hands = max(player['hands'], 1)
        cbet_opp = max(player['cbet_opp'], 1)
        threebet_opp = max(player['3bet_opp'], 1)
        check_opp = max(player['check_opp'], 1)
        raise_opp = max(player['raise_opp'], 1)
        
        # Position-based win rates
        pos_stats = {pos: player['pos_winrate'][pos]['wins'] / max(player['pos_winrate'][pos]['hands'], 1)
                     for pos in range(6)}
                     
        return {
            'vpip': float(player['vpip']),
            'pfr': float(player['pfr']),
            'af': float(player['af']),
            'fold_to_cbet': float(player['fold_to_cbet'] / cbet_opp),
            'fold_to_3bet': float(player['fold_to_3bet'] / threebet_opp),
            'check_raise_freq': float(player['check_raise'] / check_opp),
            'call_vs_raise': float(player['call_vs_raise_freq'] / raise_opp),
            'street_aggression': [float(agg) for agg in player['street_aggression']],
            'position_winrates': pos_stats
        }
        
    def get_features(self, player_id: int) -> np.ndarray:
        """Get features for model input"""
        if player_id not in self.stats:
            return np.zeros(12, dtype=np.float32)
        
        metrics = self.get_metrics(player_id)
        street_agg = metrics.get('street_aggression', [0, 0, 0, 0])
        pos_rates = list(metrics.get('position_winrates', {}).values())
        if not pos_rates:
            pos_rates = [0, 0, 0, 0, 0, 0]
            
        # Return key opponent features
        return np.array([
            metrics.get('vpip', 0),
            metrics.get('pfr', 0), 
            metrics.get('af', 0),
            metrics.get('fold_to_3bet', 0),
            metrics.get('fold_to_cbet', 0),
            street_agg[0],  # preflop aggression
            street_agg[1],  # flop aggression
            street_agg[2],  # turn aggression 
            street_agg[3],  # river aggression
            metrics.get('check_raise_freq', 0),
            metrics.get('call_vs_raise', 0),
            np.mean(list(pos_rates))  # average position win rate
        ], dtype=np.float32)
