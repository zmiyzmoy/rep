#!/bin/bash
# Startup script for Google Cloud VM instance
# This script will be executed at startup time
# Make it executable: chmod +x gcp_startup.sh

# Exit on any error
set -e

# Configuration - Update these values with your own
PROJECT_ID="YOUR_GCP_PROJECT_ID" # Replace with your GCP project ID
GCS_BUCKET="YOUR_GCS_BUCKET"     # Replace with your GCS bucket name
NUM_EPISODES=100000              # Number of episodes to train
CHECKPOINT_INTERVAL=15           # Checkpoint interval in minutes

# Install dependencies
echo "Installing dependencies..."
apt-get update
apt-get install -y git python3-pip python3-dev build-essential libopenmpi-dev

# Install CUDA and cuDNN
echo "Setting up CUDA..."
# CUDA should be pre-installed on A100 VMs, but you may need to install additional packages
apt-get install -y cuda-toolkit-11-8

# Install PyTorch with CUDA support
echo "Installing PyTorch..."
pip3 install torch==2.0.1+cu118 torchvision==0.15.2+cu118 torchaudio==2.0.2 --extra-index-url https://download.pytorch.org/whl/cu118

# Install OpenSpiel
echo "Installing OpenSpiel..."
pip3 install numpy scipy matplotlib pandas OpenSpiel==1.3

# Install other dependencies
echo "Installing other dependencies..."
pip3 install ray tqdm joblib scikit-learn requests google-cloud-storage

# Clone the repository (if using GitHub)
# git clone https://github.com/yourusername/poker-ai.git
# cd poker-ai

# Create directories
mkdir -p poker/models poker/logs poker/checkpoints

# Download the code from GCS (alternative to git clone)
echo "Downloading code from GCS..."
gsutil -m cp -r gs://${GCS_BUCKET}/code/* .

# Make scripts executable
chmod +x cloud_spot_runner.py cloud_trainer.py poker_json_inference.py

# Initialize the models if they don't exist
if [ ! -f "poker/models/psro_model.pt.final" ]; then
    echo "Initializing models..."
    python3 init_model.py
fi

# Start the training process
echo "Starting training process..."
python3 cloud_spot_runner.py \
    --checkpoint_dir="poker/checkpoints" \
    --checkpoint_interval=${CHECKPOINT_INTERVAL} \
    --total_episodes=${NUM_EPISODES} \
    --bucket=${GCS_BUCKET} \
    --project=${PROJECT_ID} \
    > training.log 2>&1 &

echo "Startup completed. Check training.log for progress."